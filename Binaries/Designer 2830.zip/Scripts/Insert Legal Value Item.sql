INSERT INTO [{LegalValueSchema}].[{tableName}]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           ({Value}
           ,{Order}
           ,'{Text}'
           ,'{ShortName}'
           ,'{Group}'
           ,'{LegalValueItemGUID}'
           ,'{Hidden}'
		   );
