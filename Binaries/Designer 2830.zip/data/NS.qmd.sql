IF NOT EXISTS(SELECT 1 FROM information_schema.schemata WHERE schema_name= 'Analysis')
EXEC ('CREATE SCHEMA [Analysis] ');
IF NOT EXISTS(SELECT 1 FROM information_schema.schemata WHERE schema_name= 'dbo')
EXEC ('CREATE SCHEMA [dbo] ');
IF NOT EXISTS(SELECT 1 FROM information_schema.schemata WHERE schema_name= 'dbo')
EXEC ('CREATE SCHEMA [dbo] ');
IF NOT EXISTS(SELECT 1 FROM information_schema.schemata WHERE schema_name= 'LegalValue')
EXEC ('CREATE SCHEMA [LegalValue] ');
CREATE TABLE [dbo].[Study]
(
	[ShortName] [nvarchar](50) NOT NULL,
	[Name] [nvarchar](100) NOT NULL,
	[Version] [nvarchar](50) NOT NULL,
	[DesignerVersion] [nvarchar](50) NOT NULL,
	[GeneratorVersion] [nvarchar](50),
	[CreationDateTime] [datetime] NOT NULL,
	[LastModificationDateTime] [datetime] NOT NULL,
	[GenerationDateTime] [datetime] 
);
INSERT INTO [dbo].[Study] (ShortName, Name, Version, DesignerVersion,CreationDateTime, LastModificationDateTime) VALUES  ('NS', 'New Study', '0.0.0', '2.8.2.0', '20110221 12:25:41', '20110406 09:37:25');
CREATE TABLE [dbo].[D_1_1_1](

	/*------------ Columns For Audit Trail ---------------*/
	
	[UpdateVersion] [int] NOT NULL,
	[InsertUser] [nvarchar](20) NOT NULL CONSTRAINT [DF_D_1_1_1_InsertUser]  DEFAULT (suser_sname()),
	[InsertDate] [datetime] NOT NULL CONSTRAINT [DF_D_1_1_1_InsertDate]  DEFAULT (getdate()),
	[InsertMsg] [nvarchar](255) NULL,
	[DBModifDate] [datetime] NOT NULL,
	[DBModifUser] [nvarchar](20) NOT NULL,
	[DBModifMsg] [nvarchar](255) NULL,
	[forDeletion] [bit] NOT NULL DEFAULT ((0)),
    
    /*----- End Of Columns Audit Trail -------------------*/
    

	CONSTRAINT [PK_D_1_1_1] PRIMARY KEY NONCLUSTERED (SubjectID,SubjectQuestionnaireInstanceID),
	
	
	SubjectID			uniqueidentifier NOT NULL,
	SubjectQuestionnaireInstanceID	tinyint NOT NULL,
	SubjectCompletedRecord	bit NOT NULL,

	PDAInsertUser		nvarchar(50) NOT NULL,
	PDAInsertDate		datetime NOT NULL,
	PDAInsertVersion	nvarchar(50) NOT NULL,
	PDAInsertSN			nvarchar(50) NOT NULL,
	PDAInsertPDAName	nvarchar(50) NOT NULL,

	PDALastModifUser	nvarchar(50),
	PDALastModifDate	datetime,
	PDALastModifVersion	nvarchar(50),
	PDALastModifSN		nvarchar(50),
	PDALastModifPDAName	nvarchar(50),

	PDALastUploadUser		nvarchar(50),
	PDALastUploadDate		datetime,
	PDALastUploadVersion	nvarchar(50),
	PDALastUploadSN			nvarchar(50),
	PDALastUploadPDAName	nvarchar(50)


	/* Add User Record Data Columns here */

	/* Add derived, calculated or asigned Columns here */

,[SeeBranchedScreen] integer
,[comment] nvarchar(255)
);
CREATE TABLE [dbo].[log_D_1_1_1](

	/*-----------CONSTRAINT for the Audit Table-----------*/

	CONSTRAINT [PK_Log_log_D_1_1_1_SubjectID_UpdateVersion] PRIMARY KEY NONCLUSTERED 

	(

		  [SubjectID] ASC,
		  
		  [SubjectQuestionnaireInstanceID] ASC, 

		  [UpdateVersion] ASC

	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY],


	/*------------ Columns For Audit Trail ---------------*/
	
	[UpdateVersion] [int] NOT NULL,
	[LogUser] [nvarchar](20) NOT NULL CONSTRAINT [DF_Log_log_D_1_1_1_LogUser]  DEFAULT (suser_sname()),
	[LogDate] [datetime] NOT NULL CONSTRAINT [DF_Log_log_D_1_1_1_LogDate]  DEFAULT (getdate()),
	[LogMsg] [nvarchar](255) NULL,
	[DBModifDate] [datetime] NOT NULL,
	[DBModifUser] [nvarchar](20) NOT NULL,
	[DBModifMsg] [nvarchar](255) NULL,
	[forDeletion] [int] NOT NULL CONSTRAINT [DF__Log_log_D_1_1_1__forDelet__0E4EF685]  DEFAULT ((0)),
    
    /*----- End Of Columns Audit Trail -------------------*/
    
    
    /* --------- We Have to remove the constraint to the SubjectID--------------*/
    
	SubjectID			uniqueidentifier NOT NULL,
	SubjectQuestionnaireInstanceID	tinyint NOT NULL,
	SubjectCompletedRecord	bit NOT NULL,

	PDAInsertUser		nvarchar(50) NOT NULL,
	PDAInsertDate		datetime NOT NULL,
	PDAInsertVersion	nvarchar(50) NOT NULL,
	PDAInsertSN			nvarchar(50) NOT NULL,
	PDAInsertPDAName	nvarchar(50) NOT NULL,

	PDALastModifUser	nvarchar(50),
	PDALastModifDate	datetime,
	PDALastModifVersion	nvarchar(50),
	PDALastModifSN		nvarchar(50),
	PDALastModifPDAName	nvarchar(50),

	PDALastUploadUser		nvarchar(50),
	PDALastUploadDate		datetime,
	PDALastUploadVersion	nvarchar(50),
	PDALastUploadSN			nvarchar(50),
	PDALastUploadPDAName	nvarchar(50)


	/* Add User Record Data Columns here */

	/* Add derived, calculated or asigned Columns here */

,[SeeBranchedScreen] integer
,[comment] nvarchar(255)
);
CREATE TABLE [dbo].[D_1_1](

	/*------------ Columns For Audit Trail ---------------*/
	
	[UpdateVersion] [int] NOT NULL,
	[InsertUser] [nvarchar](20) NOT NULL CONSTRAINT [DF_D_1_1_InsertUser]  DEFAULT (suser_sname()),
	[InsertDate] [datetime] NOT NULL CONSTRAINT [DF_D_1_1_InsertDate]  DEFAULT (getdate()),
	[InsertMsg] [nvarchar](255) NULL,
	[DBModifDate] [datetime] NOT NULL,
	[DBModifUser] [nvarchar](20) NOT NULL,
	[DBModifMsg] [nvarchar](255) NULL,
	[forDeletion] [bit] NOT NULL DEFAULT ((0)),
    
    /*----- End Of Columns Audit Trail -------------------*/
    

	CONSTRAINT [PK_D_1_1] PRIMARY KEY NONCLUSTERED (SubjectID,SubjectQuestionnaireInstanceID),
	
	
	SubjectID			uniqueidentifier NOT NULL,
	SubjectQuestionnaireInstanceID	tinyint NOT NULL,
	SubjectCompletedRecord	bit NOT NULL,

	PDAInsertUser		nvarchar(50) NOT NULL,
	PDAInsertDate		datetime NOT NULL,
	PDAInsertVersion	nvarchar(50) NOT NULL,
	PDAInsertSN			nvarchar(50) NOT NULL,
	PDAInsertPDAName	nvarchar(50) NOT NULL,

	PDALastModifUser	nvarchar(50),
	PDALastModifDate	datetime,
	PDALastModifVersion	nvarchar(50),
	PDALastModifSN		nvarchar(50),
	PDALastModifPDAName	nvarchar(50),

	PDALastUploadUser		nvarchar(50),
	PDALastUploadDate		datetime,
	PDALastUploadVersion	nvarchar(50),
	PDALastUploadSN			nvarchar(50),
	PDALastUploadPDAName	nvarchar(50)


	/* Add User Record Data Columns here */

	/* Add derived, calculated or asigned Columns here */

);
CREATE TABLE [dbo].[log_D_1_1](

	/*-----------CONSTRAINT for the Audit Table-----------*/

	CONSTRAINT [PK_Log_log_D_1_1_SubjectID_UpdateVersion] PRIMARY KEY NONCLUSTERED 

	(

		  [SubjectID] ASC,
		  
		  [SubjectQuestionnaireInstanceID] ASC, 

		  [UpdateVersion] ASC

	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY],


	/*------------ Columns For Audit Trail ---------------*/
	
	[UpdateVersion] [int] NOT NULL,
	[LogUser] [nvarchar](20) NOT NULL CONSTRAINT [DF_Log_log_D_1_1_LogUser]  DEFAULT (suser_sname()),
	[LogDate] [datetime] NOT NULL CONSTRAINT [DF_Log_log_D_1_1_LogDate]  DEFAULT (getdate()),
	[LogMsg] [nvarchar](255) NULL,
	[DBModifDate] [datetime] NOT NULL,
	[DBModifUser] [nvarchar](20) NOT NULL,
	[DBModifMsg] [nvarchar](255) NULL,
	[forDeletion] [int] NOT NULL CONSTRAINT [DF__Log_log_D_1_1__forDelet__0E4EF685]  DEFAULT ((0)),
    
    /*----- End Of Columns Audit Trail -------------------*/
    
    
    /* --------- We Have to remove the constraint to the SubjectID--------------*/
    
	SubjectID			uniqueidentifier NOT NULL,
	SubjectQuestionnaireInstanceID	tinyint NOT NULL,
	SubjectCompletedRecord	bit NOT NULL,

	PDAInsertUser		nvarchar(50) NOT NULL,
	PDAInsertDate		datetime NOT NULL,
	PDAInsertVersion	nvarchar(50) NOT NULL,
	PDAInsertSN			nvarchar(50) NOT NULL,
	PDAInsertPDAName	nvarchar(50) NOT NULL,

	PDALastModifUser	nvarchar(50),
	PDALastModifDate	datetime,
	PDALastModifVersion	nvarchar(50),
	PDALastModifSN		nvarchar(50),
	PDALastModifPDAName	nvarchar(50),

	PDALastUploadUser		nvarchar(50),
	PDALastUploadDate		datetime,
	PDALastUploadVersion	nvarchar(50),
	PDALastUploadSN			nvarchar(50),
	PDALastUploadPDAName	nvarchar(50)


	/* Add User Record Data Columns here */

	/* Add derived, calculated or asigned Columns here */

);
CREATE TABLE [dbo].[S_1](
	/*------------ Columns For Audit Trail ---------------*/
	
	[UpdateVersion] [int] NOT NULL,
	[InsertUser] [nvarchar](50) NOT NULL CONSTRAINT [DF_S_1_InsertUser]  DEFAULT (suser_sname()),
	[InsertDate] [datetime] NOT NULL CONSTRAINT [DF_S_1_InsertDate]  DEFAULT (getdate()),
	[InsertMsg] [nvarchar](255) NULL,
	[DBModifDate] [datetime] NOT NULL,
	[DBModifUser] [nvarchar](50) NOT NULL,
	[DBModifMsg] [nvarchar](255) NULL,
	[forDeletion] [int] NOT NULL DEFAULT ((0)),
	
    /*----- End Of Columns Audit Trail -------------------*/
        
	CONSTRAINT [PK_S_1] PRIMARY KEY NONCLUSTERED (SubjectID),
    
	SubjectID				uniqueidentifier NOT NULL,
	SubjectSiteID			int NOT NULL,
	SubjectCompletedStudy	bit NOT NULL,

	PDAInsertUser		nvarchar(50) NOT NULL,
	PDAInsertDate		datetime NOT NULL,
	PDAInsertVersion	nvarchar(50) NOT NULL,
	PDAInsertSN			nvarchar(50) NOT NULL,
	PDAInsertPDAName	nvarchar(50) NOT NULL,

	PDALastModifUser	nvarchar(50),
	PDALastModifDate	datetime,
	PDALastModifVersion	nvarchar(50),
	PDALastModifSN		nvarchar(50),
	PDALastModifPDAName	nvarchar(50),

	PDALastUploadUser		nvarchar(50),
	PDALastUploadDate		datetime,
	PDALastUploadVersion	nvarchar(50),
	PDALastUploadSN			nvarchar(50),
	PDALastUploadPDAName	nvarchar(50),

	SubjectLastScreenID	int,
	SubjectStack		nvarchar(500),

	SASubjectID	nvarchar(50)	--Study Assigned SubjectID


	/* Add Subject Record Data Columns here */

	/* Add flags, derived, calculated or asigned Columns here */
);
CREATE INDEX IX_SASubjectID ON [dbo].[S_1](SASubjectID);
CREATE TABLE [dbo].[log_S_1](

	/*-----------CONSTRAINT for the Audit Table-----------*/

	CONSTRAINT [PK_Log_log_S_1_SubjectID_UpdateVersion] PRIMARY KEY NONCLUSTERED 

	(

		  [SubjectID] ASC,

		  [UpdateVersion] ASC

	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY],


	/*------------ Columns For Audit Trail ---------------*/
	

	/*------------ Columns For Audit Trail ---------------*/
	
	[UpdateVersion] [int] NOT NULL,
	[LogUser] [nvarchar](50) NOT NULL CONSTRAINT [DF_Log_log_S_1_LogUser]  DEFAULT (suser_sname()),
	[LogDate] [datetime] NOT NULL CONSTRAINT [DF_Log_log_S_1_LogDate]  DEFAULT (getdate()),
	[LogMsg] [nvarchar](255) NULL,
	[DBModifDate] [datetime] NOT NULL,
	[DBModifUser] [nvarchar](50) NOT NULL,
	[DBModifMsg] [nvarchar](255) NULL,
	[forDeletion] [int] NOT NULL CONSTRAINT [DF__Log_log_S_1__forDelet__0E4EF685]  DEFAULT ((0)),
    
    /*----- End Of Columns Audit Trail -------------------*/


    /* --------- We Have to remove the constraint to the SubjectID--------------*/
    
	SubjectID				uniqueidentifier NOT NULL,
	SubjectSiteID			int NOT NULL,
	SubjectCompletedStudy	bit NOT NULL,

	PDAInsertUser		nvarchar(50) NOT NULL,
	PDAInsertDate		datetime NOT NULL,
	PDAInsertVersion	nvarchar(50) NOT NULL,
	PDAInsertSN			nvarchar(50) NOT NULL,
	PDAInsertPDAName	nvarchar(50) NOT NULL,

	PDALastModifUser	nvarchar(50),
	PDALastModifDate	datetime,
	PDALastModifVersion	nvarchar(50),
	PDALastModifSN		nvarchar(50),
	PDALastModifPDAName	nvarchar(50),

	PDALastUploadUser		nvarchar(50),
	PDALastUploadDate		datetime,
	PDALastUploadVersion	nvarchar(50),
	PDALastUploadSN			nvarchar(50),
	PDALastUploadPDAName	nvarchar(50),

	SubjectLastScreenID	int,
	SubjectStack		nvarchar(500),

	SASubjectID	nvarchar(50)	--Study Assigned SubjectID


	/* Add Subject Record Data Columns here */

	/* Add flags, derived, calculated or asigned Columns here */
);
CREATE INDEX IX_SASubjectID ON [dbo].[log_S_1](SASubjectID);
CREATE VIEW [Analysis].[QSet1] AS SELECT  [D_1_1_1].[SeeBranchedScreen] AS [SeeBranchedScreen] , 
 [D_1_1_1].[comment] AS [comment] , 
 [S_1].[SASubjectID] AS [SASubjectID]  FROM [dbo].[S_1]
 LEFT JOIN [dbo].[D_1_1] ON [D_1_1].SubjectID = [S_1].SubjectID 
 LEFT JOIN [dbo].[D_1_1_1] ON [S_1].subjectid = [D_1_1_1].subjectid;
IF NOT EXISTS(SELECT 1 FROM information_schema.schemata WHERE schema_name= 'LegalValue')
EXEC ('CREATE SCHEMA [LegalValue] ');
CREATE TABLE [LegalValue].[LV_Apellido]
(
	[Value] [int] NULL
	,[Order] [int] NULL
	,[Text] [nvarchar](200) NULL
	,[ShortName] [nvarchar](50) NULL
	,[Group] [nvarchar](50) NULL
	,[Hidden] [bit] NULL
    ,[LegalValueItemGUID] UNIQUEIDENTIFIER NULL
);
INSERT INTO [LegalValue].[LV_Apellido]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1
           ,1
           ,'PÉREZ'
           ,NULL
           ,NULL
           ,'c7bd830b-efc5-443e-a1bf-92450c1a4235'
           ,'0'
		   );
CREATE TABLE [LegalValue].[LV_Departamento]
(
	[Value] [int] NULL
	,[Order] [int] NULL
	,[Text] [nvarchar](200) NULL
	,[ShortName] [nvarchar](50) NULL
	,[Group] [nvarchar](50) NULL
	,[Hidden] [bit] NULL
    ,[LegalValueItemGUID] UNIQUEIDENTIFIER NULL
);
INSERT INTO [LegalValue].[LV_Departamento]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (6
           ,1
           ,'SANTA ROSA'
           ,'santaRosa'
           ,NULL
           ,'592cad62-136a-49fb-b3e2-06dbe2d6b192'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Departamento]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (21
           ,2
           ,'JALAPA'
           ,'jalapa'
           ,NULL
           ,'ebe2e2cc-a95c-44d4-8112-8b33b0b934de'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Departamento]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (22
           ,3
           ,'JUTIAPA'
           ,'jutiapa'
           ,NULL
           ,'ceaddaed-6858-4d0c-a271-220ade9e3807'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Departamento]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (16
           ,4
           ,'ALTA VERAPAZ'
           ,'altaVerapaz'
           ,NULL
           ,'fdef3010-3546-4dad-8555-89ba841ea7ac'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Departamento]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (15
           ,5
           ,'BAJA VERAPAZ'
           ,'bajaVerapaz'
           ,NULL
           ,'0c6c1d2a-2ca8-4848-a96f-aed539fb7165'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Departamento]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (4
           ,6
           ,'CHIMALTENANGO'
           ,'chimaltenango'
           ,NULL
           ,'57f07c1a-fd0f-4cfb-852d-87dd56f74d69'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Departamento]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (20
           ,7
           ,'CHIQUIMULA'
           ,'chiquimula'
           ,NULL
           ,'ac527dc2-82cf-4305-9b00-e50330f3ab8a'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Departamento]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (2
           ,8
           ,'EL PROGRESO'
           ,'elProgreso'
           ,NULL
           ,'27413731-65d2-4c54-b7dd-819beac0a671'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Departamento]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (5
           ,9
           ,'ESCUINTLA'
           ,'escuintla'
           ,NULL
           ,'59c5a9ed-3f58-4e24-ad7e-98d087aecbca'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Departamento]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1
           ,10
           ,'GUATEMALA'
           ,'guatemala'
           ,NULL
           ,'55ffad7f-0387-4a02-8ed2-46106b894595'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Departamento]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (13
           ,11
           ,'HUEHUETENANGO'
           ,'huehuetenango'
           ,NULL
           ,'024fb83f-0975-4946-ac11-289f456cb3c1'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Departamento]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (18
           ,12
           ,'IZABAL'
           ,'izabal'
           ,NULL
           ,'47f3ce63-7635-40d3-822e-4463a83ffc12'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Departamento]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (17
           ,13
           ,'PETEN'
           ,'peten'
           ,NULL
           ,'ac8bc368-a62c-452e-9d92-b989cfde3681'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Departamento]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (9
           ,14
           ,'QUETZALTENANGO'
           ,'quetzaltenango'
           ,NULL
           ,'096eaed7-684c-43f5-861d-57e0996334fb'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Departamento]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (14
           ,15
           ,'QUICHE'
           ,'quiche'
           ,NULL
           ,'76e4a560-85f7-4309-bf96-cd8eb283acde'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Departamento]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (11
           ,16
           ,'RETALHULEU'
           ,'retalhuleu'
           ,NULL
           ,'d9161f9a-f296-46d9-9c57-dce04cfc06ee'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Departamento]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (3
           ,17
           ,'SACATEPEQUEZ'
           ,'sacatepequez'
           ,NULL
           ,'ae8a016b-d8d5-4e09-9a19-efeec19ff23e'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Departamento]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (12
           ,18
           ,'SAN MARCOS'
           ,'sanMarcos'
           ,NULL
           ,'2ddbd621-1888-499f-a378-594457e916f0'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Departamento]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (7
           ,19
           ,'SOLOLA'
           ,'solola'
           ,NULL
           ,'8cdc0fc3-e1cc-4ab2-be6f-80e4dcc0077b'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Departamento]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (10
           ,20
           ,'SUCHITEPEQUEZ'
           ,'suchitepequez'
           ,NULL
           ,'520d8916-442a-4621-bbe5-d0cf00e2b10b'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Departamento]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (8
           ,21
           ,'TOTONICAPAN'
           ,'totonicapan'
           ,NULL
           ,'ee051316-6631-418b-a625-9173afe5217e'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Departamento]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (19
           ,22
           ,'ZACAPA'
           ,'zacapa'
           ,NULL
           ,'e18c960f-f8b0-42e4-814b-f262d2ada386'
           ,'0'
		   );
CREATE TABLE [LegalValue].[LV_Diagnostico]
(
	[Value] [int] NULL
	,[Order] [int] NULL
	,[Text] [nvarchar](200) NULL
	,[ShortName] [nvarchar](50) NULL
	,[Group] [nvarchar](50) NULL
	,[Hidden] [bit] NULL
    ,[LegalValueItemGUID] UNIQUEIDENTIFIER NULL
);
INSERT INTO [LegalValue].[LV_Diagnostico]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1
           ,1
           ,'Absceso pulmonar'
           ,'AbscesoPulmonar'
           ,NULL
           ,'9455c8d4-4295-4d07-b29a-03324ab420fa'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Diagnostico]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (2
           ,2
           ,'Amebiasis'
           ,'Amebiasis'
           ,NULL
           ,'4104f00e-70d2-46d1-a630-45ca9a7b5625'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Diagnostico]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (3
           ,3
           ,'Bronchiectasis'
           ,'Bronchiectasis'
           ,NULL
           ,'b32b7da8-f2d2-4396-b3f1-56539caec3cb'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Diagnostico]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (4
           ,4
           ,'Bronconeumonía (BNM)'
           ,'Bronconeumonia'
           ,NULL
           ,'899b65f3-2192-473d-b7c8-3bc3c1e883bd'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Diagnostico]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (5
           ,5
           ,'Bronquioespasma'
           ,'Bronquioespasma'
           ,NULL
           ,'c9db3631-9108-41b2-9538-04479ed2aad5'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Diagnostico]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (6
           ,6
           ,'Bronquiolitos'
           ,'Bronquiolitos'
           ,NULL
           ,'e5e2e114-d68e-4c38-b4b2-63582b9106f3'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Diagnostico]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (7
           ,7
           ,'Bronquitis hiperactiva'
           ,'BronquitisHiperactiva'
           ,NULL
           ,'1f1a0760-0246-4625-a999-a250efe42a40'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Diagnostico]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (8
           ,8
           ,'Cianosis'
           ,'Cianosis'
           ,NULL
           ,'dcb712dd-590d-47dc-8fe1-7e9062b584a8'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Diagnostico]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (9
           ,9
           ,'Cólera'
           ,'Colera'
           ,NULL
           ,'184a5945-6ab3-4ec2-8542-7bd38297dbfa'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Diagnostico]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (10
           ,10
           ,'Croup'
           ,'Croup'
           ,NULL
           ,'686937dc-b8c8-481f-aa65-e18f816c6620'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Diagnostico]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (11
           ,11
           ,'Deshidratación '
           ,'Deshidratacion'
           ,NULL
           ,'44da686c-706a-429e-94a6-496234c4bc6c'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Diagnostico]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (12
           ,12
           ,'DHE (Desbalance hydrolitico) '
           ,'DesbalanceHydrolitico'
           ,NULL
           ,'e02fc607-1ff2-4865-a9d6-3af95074ba37'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Diagnostico]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (13
           ,13
           ,'Diarrea (Diarrea liquida aguda, DLA)'
           ,'DiarreaLiquidaAguda'
           ,NULL
           ,'815abbcc-20d4-4cdc-9e8e-646bb61a24dc'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Diagnostico]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (14
           ,14
           ,'Dificultad respiratoria'
           ,'DificultadRespiratoria'
           ,NULL
           ,'8f07764d-4fc1-4b92-9d2a-a693fee739f5'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Diagnostico]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (15
           ,15
           ,'Disentería '
           ,'Disenteria'
           ,NULL
           ,'696258d1-4e26-433e-bea5-fe9e0181188e'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Diagnostico]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (16
           ,16
           ,'Disnea'
           ,'Disnea'
           ,NULL
           ,'3866fc97-ac94-48eb-8bea-7424bbfe7827'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Diagnostico]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (17
           ,17
           ,'Dolor abdominal'
           ,'DolorAbdominal'
           ,NULL
           ,'67cf8e40-9ce9-4a68-b196-9fe19e094d91'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Diagnostico]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (18
           ,18
           ,'Dolor toráxico'
           ,'DolorToraxico'
           ,NULL
           ,'b2a4b2ec-4a9b-4d13-a480-236690bc12f3'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Diagnostico]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (19
           ,19
           ,'Enfermedad pulmonaria obstructivo crónica (EPOC)'
           ,'EnfermedadPulmonariaObstructivoCronica'
           ,NULL
           ,'bcaf4768-cbe2-47be-aa62-8f0f20b5e449'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Diagnostico]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (20
           ,20
           ,'Enteritis'
           ,'Enteritis'
           ,NULL
           ,'4b948d49-a9fe-4665-9c6a-2721300e0499'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Diagnostico]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (21
           ,21
           ,'Faringitis, amigdalitis o laringotraqueitis'
           ,'FaringitisAmigdalitisLaringotraqueitis'
           ,NULL
           ,'206330b2-8663-4f47-92b3-c2baa5361b95'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Diagnostico]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (22
           ,22
           ,'Fatiga'
           ,'Fatiga'
           ,NULL
           ,'d5784981-a0a9-4b1a-b5c4-75cb353908ac'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Diagnostico]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (23
           ,23
           ,'Fiebre (o fiebre convulsivo)'
           ,'FiebreOFiebreConvulsivo'
           ,NULL
           ,'3b440f0e-3023-42eb-b266-3b9ed4eded00'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Diagnostico]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (24
           ,24
           ,'Fiebre estudio'
           ,'FiebreEstudio'
           ,NULL
           ,'74e46bac-d884-4d1d-aa01-470a1c9f59e2'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Diagnostico]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (25
           ,25
           ,'Fiebre tifoidea'
           ,'FiebreTifoidea'
           ,NULL
           ,'a4b72be9-34a9-494d-bed7-27b2adcd5f48'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Diagnostico]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (26
           ,26
           ,'Gastroenteritis'
           ,'Gastroenteritis'
           ,NULL
           ,'2d8cfbd9-5447-4f6d-bca5-5e8a76c19b16'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Diagnostico]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (27
           ,27
           ,'Heces con sangre'
           ,'HecesConSangre'
           ,NULL
           ,'fb5a7425-0a87-4e95-b026-337ced80170a'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Diagnostico]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (28
           ,28
           ,'Infección intestinal'
           ,'InfeccionIntestinal'
           ,NULL
           ,'daa92d6d-43e6-4049-ae10-13a4ae670a99'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Diagnostico]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (29
           ,29
           ,'Infección respiratoria superior (IRS)'
           ,'InfeccionRespiratoriaSuperior'
           ,NULL
           ,'66cb9f37-f5cd-4f38-8c22-d9079937d508'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Diagnostico]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (30
           ,30
           ,'Neumonía (NM)'
           ,'Neumonia'
           ,NULL
           ,'028859e0-ba17-405a-a248-9eeee847e1ae'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Diagnostico]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (31
           ,31
           ,'Otitis media'
           ,'OtitisMedia'
           ,NULL
           ,'afe7800f-e404-4a57-bc96-9eebe91ae20e'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Diagnostico]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (32
           ,32
           ,'Parasitismo'
           ,'Parasitismo'
           ,NULL
           ,'32f725b4-ca96-4c19-b368-c49a7343ccf2'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Diagnostico]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (33
           ,33
           ,'Pleuritis (o derrame pleural)'
           ,'PleuritisODerramePleural'
           ,NULL
           ,'c47bc532-da1e-4ba5-b3fe-005454d5855c'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Diagnostico]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (34
           ,34
           ,'Rotavirus'
           ,'Rotavirus'
           ,NULL
           ,'cef586aa-fec7-47cf-80b3-9f1d4d262605'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Diagnostico]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (35
           ,35
           ,'SDA (Síndrome diarrea agudo)'
           ,'SindromeDiarreaAgudo'
           ,NULL
           ,'a12e9a7f-76bb-48e7-8d8f-f5814da87b29'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Diagnostico]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (36
           ,36
           ,'Sepsis (o septic shock)'
           ,'Sepsis'
           ,NULL
           ,'2c9c44ad-3cb7-426b-a2d0-adfd0c4e107d'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Diagnostico]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (37
           ,37
           ,'Tos (o tos hemoptisis)'
           ,'TosOTosHemoptisis'
           ,NULL
           ,'3e8a78aa-95df-483a-bef7-f31820fa810c'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Diagnostico]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (38
           ,38
           ,'Tos en excesos'
           ,'TosEnExcesos'
           ,NULL
           ,'f29f37b6-1b0e-4355-9ec6-8b7b4df59035'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Diagnostico]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (39
           ,39
           ,'Tos ferina (o sx coquelachoina)'
           ,'TosFerinaOSXCoquelachoina'
           ,NULL
           ,'e1fb2665-94ec-4243-b4e1-8754cd222381'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Diagnostico]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (40
           ,40
           ,'Traquebronquitis o traquebronquiolitis'
           ,'TraquebronquitisOTraquebronquiolitis'
           ,NULL
           ,'08e00a30-f4e8-4eba-992e-9734b485646e'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Diagnostico]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (41
           ,41
           ,'Tuberculosis (TB) '
           ,'Tuberculosis'
           ,NULL
           ,'5e2bf2de-b138-4877-95f1-cde69e85190a'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Diagnostico]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (42
           ,42
           ,'Vómitos'
           ,'Vomitos'
           ,NULL
           ,'4db25875-0beb-4312-b2e0-734100187d7a'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Diagnostico]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (888
           ,43
           ,'Otro'
           ,'Otro'
           ,NULL
           ,'41901f18-0f96-4e2d-b644-ecd58c5d80e0'
           ,'0'
		   );
CREATE TABLE [LegalValue].[LV_GradoEscolar]
(
	[Value] [int] NULL
	,[Order] [int] NULL
	,[Text] [nvarchar](200) NULL
	,[ShortName] [nvarchar](50) NULL
	,[Group] [nvarchar](50) NULL
	,[Hidden] [bit] NULL
    ,[LegalValueItemGUID] UNIQUEIDENTIFIER NULL
);
INSERT INTO [LegalValue].[LV_GradoEscolar]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1
           ,1
           ,'Ninguno'
           ,NULL
           ,NULL
           ,'d2971d4f-1eba-435f-b2ce-88cafa90ca2c'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_GradoEscolar]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (2
           ,2
           ,'Primaria iniciada'
           ,NULL
           ,NULL
           ,'648f0d2a-b732-426f-adcb-2627ab0ee07a'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_GradoEscolar]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (3
           ,3
           ,'Primaria completa'
           ,NULL
           ,NULL
           ,'2db172dc-2642-4eab-b55c-088ff3875936'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_GradoEscolar]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (4
           ,4
           ,'Básico iniciado'
           ,NULL
           ,NULL
           ,'32dae515-2d0a-4de6-bbbc-298e45fde63a'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_GradoEscolar]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (5
           ,5
           ,'Básico completo'
           ,NULL
           ,NULL
           ,'a8fc28bf-c635-4700-a5d7-be8238083b10'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_GradoEscolar]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (6
           ,6
           ,'Secundaria iniciada'
           ,NULL
           ,NULL
           ,'01ef40dc-d6f4-4a0e-9934-396e4d859ed3'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_GradoEscolar]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (7
           ,7
           ,'Secundaria completa'
           ,NULL
           ,NULL
           ,'c6953da9-c386-48ff-a7e8-7de313df6a1a'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_GradoEscolar]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (8
           ,8
           ,'Estudios Superiores iniciados'
           ,NULL
           ,NULL
           ,'01d42609-cea7-4f98-a740-6533419961d2'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_GradoEscolar]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (9
           ,9
           ,'Estudios Superiores completos'
           ,NULL
           ,NULL
           ,'a713fb90-968b-4b83-bf8f-56b0aefc3dbc'
           ,'0'
		   );
CREATE TABLE [LegalValue].[LV_GrupoEtnico]
(
	[Value] [int] NULL
	,[Order] [int] NULL
	,[Text] [nvarchar](200) NULL
	,[ShortName] [nvarchar](50) NULL
	,[Group] [nvarchar](50) NULL
	,[Hidden] [bit] NULL
    ,[LegalValueItemGUID] UNIQUEIDENTIFIER NULL
);
INSERT INTO [LegalValue].[LV_GrupoEtnico]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1
           ,1
           ,'Indígena'
           ,'Indigena'
           ,NULL
           ,'9592feb0-f8b0-446f-aada-e7c83395eac1'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_GrupoEtnico]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (2
           ,2
           ,'Ladino'
           ,'Ladino'
           ,NULL
           ,'d2a0aee4-1f29-4ba5-a744-f1872309de79'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_GrupoEtnico]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (3
           ,3
           ,'Garífuna'
           ,'Garifuna'
           ,NULL
           ,'7da5209f-58d6-408d-b346-d5f973a457d7'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_GrupoEtnico]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (4
           ,4
           ,'Xinca'
           ,'Xinca'
           ,NULL
           ,'5f39679a-0146-499a-abab-f5caef12ec2e'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_GrupoEtnico]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (888
           ,5
           ,'Otro'
           ,'Otro'
           ,NULL
           ,'25910702-1896-4bba-80f6-e143a77d5be4'
           ,'0'
		   );
CREATE TABLE [LegalValue].[LV_Municipio]
(
	[Value] [int] NULL
	,[Order] [int] NULL
	,[Text] [nvarchar](200) NULL
	,[ShortName] [nvarchar](50) NULL
	,[Group] [nvarchar](50) NULL
	,[Hidden] [bit] NULL
    ,[LegalValueItemGUID] UNIQUEIDENTIFIER NULL
);
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (614
           ,1
           ,'NUEVA SANTA ROSA'
           ,'NUEVASANTAROSA'
           ,'6'
           ,'07d381e0-13a1-4deb-ba9b-d8b1081dea73'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (601
           ,2
           ,'CUILAPA'
           ,'CUILAPA'
           ,'6'
           ,'6b26f664-515c-4d21-9d74-24c2a3d1ab02'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (602
           ,3
           ,'BARBERENA'
           ,'BARBERENA'
           ,'6'
           ,'dee45a48-9f2d-4465-a61b-18d818721e68'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (603
           ,4
           ,'SANTA ROSA DE LIMA'
           ,'SANTAROSADELIMA'
           ,'6'
           ,'ac3a486f-a413-43ea-b29c-31371ddf254b'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (604
           ,5
           ,'CASILLAS'
           ,'CASILLAS'
           ,'6'
           ,'4b84821a-7fd4-43d7-ab24-e16933f1520c'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (605
           ,6
           ,'SAN RAFAEL LAS FLORES'
           ,'SANRAFAELLASFLORES'
           ,'6'
           ,'2fe22492-de96-4285-b864-018b68a79972'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (606
           ,7
           ,'ORATORIO'
           ,'ORATORIO'
           ,'6'
           ,'8784b76a-f812-4229-9cb2-be03c0058b05'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (607
           ,8
           ,'SAN JUAN TECUACO'
           ,'SANJUANTECUACO'
           ,'6'
           ,'79c80a41-943b-4689-b779-e6de6cad2ba9'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (608
           ,9
           ,'CHIQUIMULILLA'
           ,'CHIQUIMULILLA'
           ,'6'
           ,'7002b87b-d63f-4600-b088-87d8aa3ed052'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (609
           ,10
           ,'TAXISCO'
           ,'TAXISCO'
           ,'6'
           ,'8100a1a9-dfd4-4bc8-8de6-43021e4f50b5'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (610
           ,11
           ,'SANTA MARIA IXHUATAN'
           ,'SANTAMARIAIXHUATAN'
           ,'6'
           ,'7838f2da-a205-45ca-987e-4741db661c4f'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (611
           ,12
           ,'GUAZACAPAN'
           ,'GUAZACAPAN'
           ,'6'
           ,'d1a6d48a-f629-4bec-ab9e-8b2cb0c1c1cf'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (612
           ,13
           ,'SANTA CRUZ NARANJO'
           ,'SANTACRUZNARANJO'
           ,'6'
           ,'f7df9ede-a4a8-4783-8069-00eb979e9357'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (613
           ,14
           ,'PUEBLO NUEVO VIÑAS'
           ,'PUEBLONUEVOVINAS'
           ,'6'
           ,'6d48a16c-c026-46e4-bef3-9333e589e7cc'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (2101
           ,15
           ,'JALAPA'
           ,'JALAPA'
           ,'21'
           ,'6381a3bc-decf-4e3f-9d6b-d2e9a3283d20'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (2102
           ,16
           ,'SAN PEDRO PINULA'
           ,'SANPEDROPINULA'
           ,'21'
           ,'3d96ebb5-54ba-470a-af7e-07a47580ef1b'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (2103
           ,17
           ,'SAN LUIS JILOTEPEQUE'
           ,'SANLUISJILOTEPEQUE'
           ,'21'
           ,'bb49178f-9aab-4f2b-8bf8-6024fea5ca71'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (2104
           ,18
           ,'SAN MANUEL CHAPARRON'
           ,'SANMANUELCHAPARRON'
           ,'21'
           ,'c4f2b2fd-9517-408f-9f5b-40162d3de363'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (2105
           ,19
           ,'SAN CARLOS ALZATATE'
           ,'SANCARLOSALZATATE'
           ,'21'
           ,'404859e8-7d50-4bae-9f5e-e70d83610911'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (2106
           ,20
           ,'MONJAS'
           ,'MONJAS'
           ,'21'
           ,'43b669d1-ce51-41af-8f4e-d14716ad4596'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (2107
           ,21
           ,'MATAQUESCUINTLA'
           ,'MATAQUESCUINTLA'
           ,'21'
           ,'d21e115c-1f8c-48cd-bf7d-4517f02e074e'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (2201
           ,22
           ,'JUTIAPA'
           ,'JUTIAPA'
           ,'22'
           ,'236300f4-cf9e-4e7f-8127-098b986b60d1'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (2202
           ,23
           ,'EL PROGRESO'
           ,'ELPROGRESO'
           ,'22'
           ,'9e71411e-aa9a-460b-9253-ca1ba3d128eb'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (2203
           ,24
           ,'SANTA CATARINA MITA'
           ,'SANTACATARINAMITA'
           ,'22'
           ,'a1756ba2-aaaa-4001-9afb-6636a296b81a'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (2204
           ,25
           ,'AGUA BLANCA'
           ,'AGUABLANCA'
           ,'22'
           ,'cf424dda-aea4-4e55-8342-752854bb195f'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (2205
           ,26
           ,'ASUNCION MITA'
           ,'ASUNCIONMITA'
           ,'22'
           ,'273511d3-67ed-48c9-bd03-1195d34dff77'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (2206
           ,27
           ,'YUPILTEPEQUE'
           ,'YUPILTEPEQUE'
           ,'22'
           ,'3d67d8d6-2ec3-4712-9361-ed41d0ab85a1'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (2207
           ,28
           ,'ATESCATEMPA'
           ,'ATESCATEMPA'
           ,'22'
           ,'b96a6182-2d59-4699-a63b-e18fd6eee225'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (2208
           ,29
           ,'JEREZ'
           ,'JEREZ'
           ,'22'
           ,'ab2f807c-5bce-45d7-8445-d62d9bb9091d'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (2209
           ,30
           ,'EL ADELANTO'
           ,'ELADELANTO'
           ,'22'
           ,'2a182400-3d57-4d79-8bf8-5b1d0f758892'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (2210
           ,31
           ,'ZAPOTITLAN'
           ,'ZAPOTITLAN'
           ,'22'
           ,'0a349ea7-7c19-491b-8e18-6ac46f3895b1'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (2211
           ,32
           ,'COMAPA'
           ,'COMAPA'
           ,'22'
           ,'37868ed4-f0a9-4de8-b15e-23de6676ab0e'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (2212
           ,33
           ,'JALPATAGUA'
           ,'JALPATAGUA'
           ,'22'
           ,'235ec0c6-bc8a-49e8-98c0-deb468f22a2e'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (2213
           ,34
           ,'CONGUACO'
           ,'CONGUACO'
           ,'22'
           ,'613aad34-f62c-4b80-be31-130d14adf0bc'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (2214
           ,35
           ,'MOYUTA'
           ,'MOYUTA'
           ,'22'
           ,'089cc038-813b-421c-8ac7-602b74d798c6'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (2215
           ,36
           ,'PASACO'
           ,'PASACO'
           ,'22'
           ,'36439fad-85d1-40fe-88d5-106f5fb5c8dc'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (2216
           ,37
           ,'SAN JOSE ACATEMPA'
           ,'SANJOSEACATEMPA'
           ,'22'
           ,'a2206719-ca76-4bf3-91b3-c1765ecfdcf8'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (2217
           ,38
           ,'QUEZADA'
           ,'QUEZADA'
           ,'22'
           ,'27c4d39c-6909-45f9-96d9-c24c76e5c5fb'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (101
           ,39
           ,'ZONA 19'
           ,'ZONA19'
           ,'1'
           ,'859feab4-701f-4d61-a5af-a2fa84206504'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (101
           ,40
           ,'ZONA 15'
           ,'ZONA15'
           ,'1'
           ,'e5f68b15-89e6-4c75-bb81-aac48978facc'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (101
           ,41
           ,'ZONA 14'
           ,'ZONA14'
           ,'1'
           ,'25f32977-080a-4f94-95e5-6512a63c4702'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (101
           ,42
           ,'ZONA 16'
           ,'ZONA16'
           ,'1'
           ,'44402600-898a-473d-b3c9-4734c94a2bf4'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (101
           ,43
           ,'ZONA 1'
           ,'ZONA1'
           ,'1'
           ,'4d860f01-c36a-42fb-982c-51ae3f9683c8'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (101
           ,44
           ,'ZONA 17'
           ,'ZONA17'
           ,'1'
           ,'7f94e579-08c4-446f-93a6-79add653c412'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (101
           ,45
           ,'ZONA 13'
           ,'ZONA13'
           ,'1'
           ,'f69a7595-2e77-4f33-9019-b4c0f5b10dfb'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (101
           ,46
           ,'ZONA 18'
           ,'ZONA18'
           ,'1'
           ,'b6d975ff-c5c1-4731-af3d-3298e4ab5baf'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (101
           ,47
           ,'ZONA 2'
           ,'ZONA2'
           ,'1'
           ,'0ca4ebf2-3949-44f7-b7ef-2504de0e5e17'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (101
           ,48
           ,'ZONA 21'
           ,'ZONA21'
           ,'1'
           ,'1959f442-3c2b-4a1e-8b6f-bb0ab6a9582e'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (101
           ,49
           ,'ZONA 24'
           ,'ZONA24'
           ,'1'
           ,'6455f1c2-1589-42ed-969e-b164afc8365d'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (101
           ,50
           ,'ZONA 8'
           ,'ZONA8'
           ,'1'
           ,'270be0cf-bd99-493c-b781-5a9adac88f95'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (101
           ,51
           ,'ZONA 10'
           ,'ZONA10'
           ,'1'
           ,'c0a8f619-956a-4e90-b3f5-a33bb590596f'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (101
           ,52
           ,'ZONA 11'
           ,'ZONA11'
           ,'1'
           ,'ca2007e4-3ec8-44bb-807a-411aa57fafcc'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (101
           ,53
           ,'ZONA 12'
           ,'ZONA12'
           ,'1'
           ,'962f8d41-31d6-40e3-85b4-62ca4cd95445'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (101
           ,54
           ,'ZONA 9'
           ,'ZONA9'
           ,'1'
           ,'9f1299cf-5bb2-43b4-86f0-65d9817944aa'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (101
           ,55
           ,'ZONA 25'
           ,'ZONA25'
           ,'1'
           ,'f720ba00-a6dd-41aa-9eff-f8452e27bcdd'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (101
           ,56
           ,'ZONA 7'
           ,'ZONA7'
           ,'1'
           ,'7fe6c55c-e83e-437e-956e-f1d49b88622f'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (101
           ,57
           ,'ZONA 6'
           ,'ZONA6'
           ,'1'
           ,'0b32b31c-ac2f-4a87-b2a6-017295e202ab'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (101
           ,58
           ,'ZONA 5'
           ,'ZONA5'
           ,'1'
           ,'d96e27fb-2d57-4785-81ca-208533a5d844'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (101
           ,59
           ,'ZONA 4'
           ,'ZONA4'
           ,'1'
           ,'9f07bc9c-8b65-4833-a962-39c782645551'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (101
           ,60
           ,'ZONA 3'
           ,'ZONA3'
           ,'1'
           ,'ed7fb939-3316-4b55-b6b2-c9ef8307311e'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (102
           ,61
           ,'SANTA CATARINA PINULA'
           ,'SANTACATARINAPINULA'
           ,'1'
           ,'fac0fb43-20b5-4cf3-94c0-aa0574235d25'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (103
           ,62
           ,'SAN JOSE PINULA'
           ,'SANJOSEPINULA'
           ,'1'
           ,'81809b85-68cd-495b-9aa5-984de6c1accc'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (104
           ,63
           ,'SAN JOSE DEL GOLFO'
           ,'SANJOSEDELGOLFO'
           ,'1'
           ,'255f0a68-de18-44b0-a33b-7ba5c429dca6'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (105
           ,64
           ,'PALENCIA'
           ,'PALENCIA'
           ,'1'
           ,'de2488b7-3cf9-420d-a8d4-5f6c30575af8'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (106
           ,65
           ,'CHINAUTLA'
           ,'CHINAUTLA'
           ,'1'
           ,'15f64c77-8ac3-4cb4-9464-ed7c57cb677d'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (107
           ,66
           ,'SAN PEDRO AYAMPUC'
           ,'SANPEDROAYAMPUC'
           ,'1'
           ,'b6b51c19-8362-467d-9377-447e5ba79d48'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (108
           ,67
           ,'MIXCO'
           ,'MIXCO'
           ,'1'
           ,'3c7e2b63-15e3-48d8-8a59-cbf964b3cdc2'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (109
           ,68
           ,'SAN PEDRO SACATEPEQUEZ'
           ,'SANPEDROSACATEPEQUEZ'
           ,'1'
           ,'91de931c-bf3d-4c28-b214-ed0b136a3d6f'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (110
           ,69
           ,'SAN JUAN SACATEPEQUEZ'
           ,'SANJUANSACATEPEQUEZ'
           ,'1'
           ,'5e65e077-6d46-47a4-b8bd-0e760e2f2fe9'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (111
           ,70
           ,'SAN RAIMUNDO'
           ,'SANRAIMUNDO'
           ,'1'
           ,'906f2b01-6463-43d2-9d0c-0739a00e5354'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (112
           ,71
           ,'CHUARRANCHO'
           ,'CHUARRANCHO'
           ,'1'
           ,'bcc46fd6-49c5-4779-93a6-421fe88c0afe'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (113
           ,72
           ,'FRAIJANES'
           ,'FRAIJANES'
           ,'1'
           ,'44cd30fc-867e-4eef-9bcc-d6696ea3fb18'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (114
           ,73
           ,'AMATITLAN'
           ,'AMATITLAN'
           ,'1'
           ,'1a617a7c-1ace-4060-aced-c3dadd6f10b2'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (115
           ,74
           ,'VILLA NUEVA'
           ,'VILLANUEVA'
           ,'1'
           ,'f8a09bf6-d8ad-4430-862b-74b5d523e928'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (116
           ,75
           ,'VILLA CANALES'
           ,'VILLACANALES'
           ,'1'
           ,'1aaedaf0-adcc-41fb-9290-9cb97bdba8be'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (117
           ,76
           ,'SAN MIGUEL PETAPA'
           ,'SANMIGUELPETAPA'
           ,'1'
           ,'ab6e9002-4f16-4483-99c6-b1e36fd6cbf8'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (201
           ,77
           ,'GUASTATOYA'
           ,'GUASTATOYA'
           ,'2'
           ,'ddbeb618-e3bf-4311-b9d3-82293d34c6e1'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (202
           ,78
           ,'MORAZAN'
           ,'MORAZAN'
           ,'2'
           ,'cad3d273-ccfc-4c9a-aaf8-8a6f2e0350a4'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (203
           ,79
           ,'SAN AGUSTIN ACASAGUASTLAN'
           ,'SANAGUSTINACASAGUASTLAN'
           ,'2'
           ,'e2d7a018-97dc-4dc0-8dde-230bbcf5ac89'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (204
           ,80
           ,'SAN CRISTOBAL ACASAGUASTLAN'
           ,'SANCRISTOBALACASAGUASTLAN'
           ,'2'
           ,'5964fdc0-2efa-495c-a9f7-aa8b00049a32'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (205
           ,81
           ,'EL JICARO'
           ,'ELJICARO'
           ,'2'
           ,'cf9d3a8f-ce6c-40cc-926f-ce779818ef3c'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (206
           ,82
           ,'SANSARE'
           ,'SANSARE'
           ,'2'
           ,'f3aa61d5-9d6a-48e4-be40-3a0c2b4aee61'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (207
           ,83
           ,'SANARATE'
           ,'SANARATE'
           ,'2'
           ,'01333cd4-3beb-4cf8-8ae4-18ceb0bb4f3e'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (208
           ,84
           ,'SAN ANTONIO LA PAZ'
           ,'SANANTONIOLAPAZ'
           ,'2'
           ,'10ef313e-56dc-459e-be4e-08af3834c8ba'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (301
           ,85
           ,'ANTIGUA GUATEMALA'
           ,'ANTIGUAGUATEMALA'
           ,'3'
           ,'8a7f2693-cae2-4ba8-858d-2799274785e1'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (302
           ,86
           ,'JOCOTENANGO'
           ,'JOCOTENANGO'
           ,'3'
           ,'2360fe7f-84e0-4c39-b7ca-1f123bbbd97a'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (303
           ,87
           ,'PASTORES'
           ,'PASTORES'
           ,'3'
           ,'394e0c21-fb8e-4631-b09e-5fae83184871'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (304
           ,88
           ,'SUMPANGO'
           ,'SUMPANGO'
           ,'3'
           ,'f25c7bb0-9bd7-4040-b855-ff58a0b46632'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (305
           ,89
           ,'SANTO DOMINGO XENACOJ'
           ,'SANTODOMINGOXENACOJ'
           ,'3'
           ,'b7caf007-98cf-4b62-851c-e6e534264ecb'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (306
           ,90
           ,'SANTIAGO SACATEPEQUEZ'
           ,'SANTIAGOSACATEPEQUEZ'
           ,'3'
           ,'fa826371-c550-413b-bfab-b3a3eb8e9362'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (307
           ,91
           ,'SAN BARTOLOME MILPAS ALTAS'
           ,'SANBARTOLOMEMILPASALTAS'
           ,'3'
           ,'97120df9-5f8e-4cfb-8eab-8e166bb7af3f'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (308
           ,92
           ,'SAN LUCAS SACATEPEQUEZ'
           ,'SANLUCASSACATEPEQUEZ'
           ,'3'
           ,'90b8c6b3-d435-4885-bd66-6dc9aa448fc7'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (309
           ,93
           ,'SANTA LUCIA MILPAS ALTAS'
           ,'SANTALUCIAMILPASALTAS'
           ,'3'
           ,'e1a4c0f6-912e-4a59-9134-3ab2776558ba'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (310
           ,94
           ,'MAGDALENA MILPAS ALTAS'
           ,'MAGDALENAMILPASALTAS'
           ,'3'
           ,'f961bc28-97be-46fc-958c-85b5b3e2fc01'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (311
           ,95
           ,'SANTA MARIA DE JESUS'
           ,'SANTAMARIADEJESUS'
           ,'3'
           ,'f9f9b5bf-76de-4f1c-8979-5469f583f50b'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (312
           ,96
           ,'CIUDAD VIEJA'
           ,'CIUDADVIEJA'
           ,'3'
           ,'c5ac7cc7-4615-43a3-9fa5-aa1ea4c5f686'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (313
           ,97
           ,'SAN MIGUEL DUEÑAS'
           ,'SANMIGUELDUENAS'
           ,'3'
           ,'b887bbf3-2b79-43fe-994a-85614cad96cd'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (314
           ,98
           ,'ALOTENANGO'
           ,'ALOTENANGO'
           ,'3'
           ,'d31fc5a4-e9c6-4983-bbe4-08c460796af9'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (315
           ,99
           ,'SAN ANTONIO AGUAS CALIENTES'
           ,'SANANTONIOAGUASCALIENTES'
           ,'3'
           ,'d3dc9b3e-2fac-4144-a56d-6b59c5dacb1d'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (316
           ,100
           ,'SANTA CATARINA BARAHONA'
           ,'SANTACATARINABARAHONA'
           ,'3'
           ,'2baf591d-9f0a-4ef7-9dfc-d7e039f6ffbe'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (401
           ,101
           ,'CHIMALTENAGO'
           ,'CHIMALTENAGO'
           ,'4'
           ,'244dedc6-61a6-4d46-a87d-6f921d9a60d6'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (402
           ,102
           ,'SAN JOSE POAQUIL'
           ,'SANJOSEPOAQUIL'
           ,'4'
           ,'bf526de0-f7e1-48c3-8a29-ceff70ee6f55'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (403
           ,103
           ,'SAN MARTIN  JILOTEPEQUE'
           ,'SANMARTINJILOTEPEQUE'
           ,'4'
           ,'af67c179-da8f-42fb-b8e4-606c5b99def7'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (404
           ,104
           ,'COMALAPA'
           ,'COMALAPA'
           ,'4'
           ,'50f615d4-fa17-4384-a0d9-6a527583f8a1'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (405
           ,105
           ,'SANTA APOLONIA'
           ,'SANTAAPOLONIA'
           ,'4'
           ,'aa2c337e-b765-4f1e-94b1-99123645ff20'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (406
           ,106
           ,'TECPAN GUATEMALA'
           ,'TECPANGUATEMALA'
           ,'4'
           ,'d9912684-0adb-4d9a-a2a6-98b712c4716c'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (407
           ,107
           ,'PATZUN'
           ,'PATZUN'
           ,'4'
           ,'519a6089-4f61-48ef-8a02-fe796d8de60a'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (408
           ,108
           ,'POCHUTA'
           ,'POCHUTA'
           ,'4'
           ,'e8303d0c-6381-434d-a17f-83d60cf3b19e'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (409
           ,109
           ,'PATZICIA'
           ,'PATZICIA'
           ,'4'
           ,'c9a3b268-bddc-4958-ba57-d0f2a85f06f8'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (410
           ,110
           ,'SANTA CRUZ BALANYA'
           ,'SANTACRUZBALANYA'
           ,'4'
           ,'08b6a075-48b8-424f-bdaf-f7ffec24fa69'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (411
           ,111
           ,'ACATENANGO'
           ,'ACATENANGO'
           ,'4'
           ,'214f87c5-d046-415e-b2d8-80d9cae8206e'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (412
           ,112
           ,'YEPOCAPA'
           ,'YEPOCAPA'
           ,'4'
           ,'f4356de6-56a6-4e93-89ff-c88875926ff3'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (413
           ,113
           ,'SAN ANDRES IZTAPA'
           ,'SANANDRESIZTAPA'
           ,'4'
           ,'d1e3d710-8e21-4d07-b9fb-7cfdeda6c8a7'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (414
           ,114
           ,'PARRAMOS'
           ,'PARRAMOS'
           ,'4'
           ,'428bc58f-9b74-4cb4-b9b2-a964450d73e0'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (415
           ,115
           ,'ZARAGOZA'
           ,'ZARAGOZA'
           ,'4'
           ,'d6e01768-ef95-44e0-a35f-e48c2ec057d3'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (416
           ,116
           ,'EL TEJAR'
           ,'ELTEJAR'
           ,'4'
           ,'149016b2-9c8f-430e-8e14-b786455e1f6e'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (501
           ,117
           ,'ESCUINTLA'
           ,'ESCUINTLA'
           ,'5'
           ,'e276adbf-53ee-46b6-bf05-2abcc0908747'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (502
           ,118
           ,'SAN LUCIA COTZUMALGUAPA'
           ,'SANLUCIACOTZUMALGUAPA'
           ,'5'
           ,'9bf691ba-785f-4e59-80d0-07a32b4e454b'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (503
           ,119
           ,'LA DEMOCRACIA'
           ,'LADEMOCRACIA'
           ,'5'
           ,'aca240a3-8da9-4db4-b90e-a9ac1047dcb4'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (504
           ,120
           ,'SIQUINALA'
           ,'SIQUINALA'
           ,'5'
           ,'adceae96-53de-4f03-8055-efb30cb619aa'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (505
           ,121
           ,'MASAGUA'
           ,'MASAGUA'
           ,'5'
           ,'8e210a28-f6d1-432b-9f81-ce433df9ca28'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (506
           ,122
           ,'TIQUISATE'
           ,'TIQUISATE'
           ,'5'
           ,'0fd4fc8d-7ef0-4520-a03c-f78dcc5470f8'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (507
           ,123
           ,'LA GOMERA'
           ,'LAGOMERA'
           ,'5'
           ,'8947b3b5-8761-4664-86ee-ef696032685a'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (508
           ,124
           ,'GUANAGAZAPA'
           ,'GUANAGAZAPA'
           ,'5'
           ,'2139f3f1-61e2-4605-bf7e-35ee12c6fec0'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (509
           ,125
           ,'SAN JOSE'
           ,'SANJOSE'
           ,'5'
           ,'5b5f0fcd-8a68-4e87-b0a2-74980c023757'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (510
           ,126
           ,'IZTAPA'
           ,'IZTAPA'
           ,'5'
           ,'0e18a219-39f0-454b-bb4d-9f365d8134e3'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (511
           ,127
           ,'PALIN'
           ,'PALIN'
           ,'5'
           ,'7230a92f-cbc2-434a-aa60-137d3d39773b'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (512
           ,128
           ,'SAN VICENTE PACAYA'
           ,'SANVICENTEPACAYA'
           ,'5'
           ,'31950cc8-f2b7-4ca0-bd3c-dd3e424f582b'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (513
           ,129
           ,'NUEVA CONCEPCION'
           ,'NUEVACONCEPCION'
           ,'5'
           ,'30f069d1-d98e-4052-89eb-b96bba6d4b7a'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (701
           ,130
           ,'SOLOLA'
           ,'SOLOLA'
           ,'7'
           ,'b7e1b646-29b0-4a3e-bb32-efe232ac2279'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (702
           ,131
           ,'SAN JOSE CHACAYA'
           ,'SANJOSECHACAYA'
           ,'7'
           ,'fec20a63-1d09-42c6-a1a2-cff115a5847c'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (703
           ,132
           ,'SANTA MARIA VISITACION'
           ,'SANTAMARIAVISITACION'
           ,'7'
           ,'ab822dc9-b11e-4e25-a0bb-fdd77be0d26b'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (704
           ,133
           ,'SANTA LUCIA UTATLAN'
           ,'SANTALUCIAUTATLAN'
           ,'7'
           ,'81e70c7f-9b44-4ff7-a545-bcfee25e1996'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (705
           ,134
           ,'NAHUALA'
           ,'NAHUALA'
           ,'7'
           ,'af6521c0-109e-417a-990e-ae40f6c4578e'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (706
           ,135
           ,'SANTA CATARINA IXTAHUACAN'
           ,'SANTACATARINAIXTAHUACAN'
           ,'7'
           ,'988c2c3f-c468-4a22-95b2-d5438f4a13e3'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (707
           ,136
           ,'SANTA CLARA LA LAGUNA'
           ,'SANTACLARALALAGUNA'
           ,'7'
           ,'b78a92c5-6aeb-422f-b746-e88cc7670bbe'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (708
           ,137
           ,'CONCEPCION'
           ,'CONCEPCION'
           ,'7'
           ,'636ded95-6e55-4de0-8a7b-99e116645c52'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (709
           ,138
           ,'SAN ANDRES SEMETABAJ'
           ,'SANANDRESSEMETABAJ'
           ,'7'
           ,'0e264cde-11c4-4d0c-a9a4-058cac0b15c0'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (710
           ,139
           ,'PANAJACHEL'
           ,'PANAJACHEL'
           ,'7'
           ,'662db0e4-88f6-41b1-ad13-2c3b15cb9909'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (711
           ,140
           ,'SANTA CATARINA PALOPO'
           ,'SANTACATARINAPALOPO'
           ,'7'
           ,'395f4725-e07c-4ba0-a3a9-dd805cef9090'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (712
           ,141
           ,'SAN ANTONIO PALOPO'
           ,'SANANTONIOPALOPO'
           ,'7'
           ,'e44add90-522c-411c-95f2-d8e3978be617'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (713
           ,142
           ,'SAN LUCAS TOLIMAN'
           ,'SANLUCASTOLIMAN'
           ,'7'
           ,'eb2e380d-b0dc-4a54-ab11-d264e1d35a21'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (714
           ,143
           ,'SANTA CRUZ LA LAGUNA'
           ,'SANTACRUZLALAGUNA'
           ,'7'
           ,'2cbfbab1-0f8d-4804-b68c-31b2630e6a2b'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (715
           ,144
           ,'SAN PABLO LA LAGUNA'
           ,'SANPABLOLALAGUNA'
           ,'7'
           ,'31c9e093-e4f5-4513-a4c9-6c689b3f8018'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (716
           ,145
           ,'SAN MARCOS LA LAGUNA'
           ,'SANMARCOSLALAGUNA'
           ,'7'
           ,'df9c3a3f-5fa4-4d4a-98d7-17c1b552fff5'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (717
           ,146
           ,'SAN JUAN LA LAGUNA'
           ,'SANJUANLALAGUNA'
           ,'7'
           ,'6c642c37-4ea4-4434-a8ea-e63c17e24c88'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (718
           ,147
           ,'SAN PEDRO LA LAGUNA'
           ,'SANPEDROLALAGUNA'
           ,'7'
           ,'d6781d43-7649-42f3-9f29-d1f4760abeb8'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (719
           ,148
           ,'SANTIAGO ATITLAN'
           ,'SANTIAGOATITLAN'
           ,'7'
           ,'4d0a63ca-cb63-49b6-bf48-f947dd9b9708'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (720
           ,149
           ,'LAGO ATITLAN'
           ,'LAGOATITLAN'
           ,'7'
           ,'4d4fae67-b342-4712-a229-2f0678ea6c4e'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (801
           ,150
           ,'TOTONICAPAN'
           ,'TOTONICAPAN'
           ,'8'
           ,'6aa6ef40-9786-428b-964c-51cb21b9226e'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (802
           ,151
           ,'SAN CRISTOBAL TOTONICAPAN'
           ,'SANCRISTOBALTOTONICAPAN'
           ,'8'
           ,'0ae7e159-63c3-4e1a-8c8b-3affad170796'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (803
           ,152
           ,'SAN FRANCISCO EL ALTO'
           ,'SANFRANCISCOELALTO'
           ,'8'
           ,'dfa76033-cd92-4d80-8201-c27a1960cd28'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (804
           ,153
           ,'SAN ANDRES XECUL'
           ,'SANANDRESXECUL'
           ,'8'
           ,'92d4ef1f-79c3-4a0e-a1f4-9f611f9cba99'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (805
           ,154
           ,'MOMOSTENANGO'
           ,'MOMOSTENANGO'
           ,'8'
           ,'4d251466-20fb-4eda-b25c-c5557164e3d9'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (806
           ,155
           ,'SANTA MARIA CHIQUIMULA'
           ,'SANTAMARIACHIQUIMULA'
           ,'8'
           ,'6a477a9d-77bb-4a12-badd-0e1b7a525e61'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (807
           ,156
           ,'SANTA LUCIA LA  REFORMA'
           ,'SANTALUCIALAREFORMA'
           ,'8'
           ,'fbc46a3c-a5ce-44ed-b165-696aa1966876'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (808
           ,157
           ,'SAN BARTOLO'
           ,'SANBARTOLO'
           ,'8'
           ,'e01d0d6b-81ae-40ab-ab35-7172bd3cdf3c'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (901
           ,158
           ,'QUETZALTENANGO'
           ,'QUETZALTENANGO'
           ,'9'
           ,'588e221b-2c78-434b-afd3-187370e88d7e'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (902
           ,159
           ,'SALCAJA'
           ,'SALCAJA'
           ,'9'
           ,'be007b2d-ad03-439f-9615-d9a63ee38158'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (903
           ,160
           ,'OLINTEPEQUE'
           ,'OLINTEPEQUE'
           ,'9'
           ,'0d713582-ed05-4ac6-80d1-85126a16affc'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (904
           ,161
           ,'SAN CARLOS SIJA'
           ,'SANCARLOSSIJA'
           ,'9'
           ,'1f2d5da9-0913-48f4-9d69-e942cbacdfce'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (905
           ,162
           ,'SIBILIA'
           ,'SIBILIA'
           ,'9'
           ,'1c8cca0b-c606-48a1-a9f7-273070ad37d0'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (906
           ,163
           ,'CABRICAN'
           ,'CABRICAN'
           ,'9'
           ,'cf57db9f-69b4-4665-8dbd-61632e873e86'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (907
           ,164
           ,'CAJOLA'
           ,'CAJOLA'
           ,'9'
           ,'db6b9a33-6cd7-44ec-9a8b-99d9570ca2c7'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (908
           ,165
           ,'SAN MIGUEL SIGⁿILA'
           ,'SANMIGUELSIGUILA'
           ,'9'
           ,'9392f336-9f4e-4536-a8fb-584797ff087e'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (909
           ,166
           ,'OSTUNCALCO'
           ,'OSTUNCALCO'
           ,'9'
           ,'eb095444-1951-4cf7-8046-6dceebfeb713'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (910
           ,167
           ,'SAN MATEO'
           ,'SANMATEO'
           ,'9'
           ,'73a66096-8c13-4453-a921-dbd2ce9cacda'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (911
           ,168
           ,'CONCEPCION CHIQUIRICHAPA'
           ,'CONCEPCIONCHIQUIRICHAPA'
           ,'9'
           ,'5bec0f8d-3d36-41cd-8d8e-be2c90f9876c'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (912
           ,169
           ,'SAN MARTIN SACATEPEQUEZ'
           ,'SANMARTINSACATEPEQUEZ'
           ,'9'
           ,'e769ef49-3e32-4a73-ac43-6eb30ceee5a3'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (913
           ,170
           ,'ALMOLONGA'
           ,'ALMOLONGA'
           ,'9'
           ,'bfadd7d2-ce7a-4762-b362-069508d7dc9b'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (914
           ,171
           ,'CANTEL'
           ,'CANTEL'
           ,'9'
           ,'d5d72298-fab5-4084-ab70-8fb2f0570bfb'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (915
           ,172
           ,'HUITAN'
           ,'HUITAN'
           ,'9'
           ,'a3133bf1-fca9-47ce-b630-6368849b7d8e'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (916
           ,173
           ,'ZUNIL'
           ,'ZUNIL'
           ,'9'
           ,'9f266a98-f318-48fc-8a9e-c8dfc4b8e46d'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (917
           ,174
           ,'COLOMBA COSTA CUCA'
           ,'COLOMBACOSTACUCA'
           ,'9'
           ,'2f8f8782-79ed-4261-a325-c5490f723272'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (918
           ,175
           ,'SAN FRANCISCO LA UNION'
           ,'SANFRANCISCOLAUNION'
           ,'9'
           ,'fd3ba69a-5cb1-4cdd-b63e-0cfc0bbf93c0'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (919
           ,176
           ,'EL PALMAR'
           ,'ELPALMAR'
           ,'9'
           ,'820ee86d-e4cd-4570-aded-502d630e598a'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (920
           ,177
           ,'COATEPEQUE'
           ,'COATEPEQUE'
           ,'9'
           ,'37fed467-44ef-432c-8416-f848a7c77e73'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (921
           ,178
           ,'GENOVA'
           ,'GENOVA'
           ,'9'
           ,'cdd08a9c-7b0d-4b91-9f13-8c1d3b753df1'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (922
           ,179
           ,'FLORES COSTA CUCA'
           ,'FLORESCOSTACUCA'
           ,'9'
           ,'a162e581-50fc-481c-b2c0-26a1a1a2b356'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (923
           ,180
           ,'LA ESPERANZA'
           ,'LAESPERANZA'
           ,'9'
           ,'c51d5a71-bf34-4b28-a637-c85af05d60a1'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (924
           ,181
           ,'PALESTINA DE LOS ALTOS'
           ,'PALESTINADELOSALTOS'
           ,'9'
           ,'c85292b0-eb4f-42b2-a640-3a3cb04a1608'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1001
           ,182
           ,'MAZATENANGO'
           ,'MAZATENANGO'
           ,'10'
           ,'ce540ff3-9d27-4f80-96c4-da6b3d56d9d8'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1002
           ,183
           ,'CUYOTENANGO'
           ,'CUYOTENANGO'
           ,'10'
           ,'01fc2052-9348-45d5-8e96-7b392c64c9c5'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1003
           ,184
           ,'SAN FRANCISCO ZAPOTITLAN'
           ,'SANFRANCISCOZAPOTITLAN'
           ,'10'
           ,'ec4a55c0-c3c4-4365-94d9-e1d18008ff46'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1004
           ,185
           ,'SAN BERNARDINO'
           ,'SANBERNARDINO'
           ,'10'
           ,'d2fa0b91-50ed-46b2-b887-038e03e7c7a0'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1005
           ,186
           ,'SAN JOSE EL IDOLO'
           ,'SANJOSEELIDOLO'
           ,'10'
           ,'31ca9b8d-943c-4b49-8c6b-d5433ed9e963'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1006
           ,187
           ,'SANTO DOMINGO SUCHITEPEQUEZ'
           ,'SANTODOMINGOSUCHITEPEQUEZ'
           ,'10'
           ,'93f38e55-2a3e-4c3b-a81e-9d01e32180b4'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1007
           ,188
           ,'SAN LORENZO'
           ,'SANLORENZO'
           ,'10'
           ,'02e8f068-5197-447c-a2bc-732cda56b8bb'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1008
           ,189
           ,'SAMAYAC'
           ,'SAMAYAC'
           ,'10'
           ,'134c4fca-c0ad-4921-89e2-fba58c483e88'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1009
           ,190
           ,'SAN PABLO JOCOPILAS'
           ,'SANPABLOJOCOPILAS'
           ,'10'
           ,'3b234bf7-771a-4c8b-a860-3a6a2822825f'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1010
           ,191
           ,'SAN ANTONIO SUCHITEPEQUEZ'
           ,'SANANTONIOSUCHITEPEQUEZ'
           ,'10'
           ,'b13fd382-b2e0-4de1-8743-7c1876ca0e4f'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1011
           ,192
           ,'SAN MIGUEL PANAN'
           ,'SANMIGUELPANAN'
           ,'10'
           ,'c5f5388d-a707-472c-9c7f-ea55dc4bddb6'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1012
           ,193
           ,'SAN GABRIEL'
           ,'SANGABRIEL'
           ,'10'
           ,'fde71d1c-226e-41be-8e4c-42d787910d76'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1013
           ,194
           ,'CHICACAO'
           ,'CHICACAO'
           ,'10'
           ,'34696762-a016-4281-86ac-33e340a5063f'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1014
           ,195
           ,'PATULUL'
           ,'PATULUL'
           ,'10'
           ,'a994a528-003b-4ebf-872d-4fe7e2850da0'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1015
           ,196
           ,'SANTA BARBARA'
           ,'SANTABARBARA'
           ,'10'
           ,'793d6d5b-f9e3-4791-9d25-ea8acf95b3bc'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1016
           ,197
           ,'SAN JUAN BAUTISTA'
           ,'SANJUANBAUTISTA'
           ,'10'
           ,'836fadbc-0a87-4517-96f1-e688958e7155'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1017
           ,198
           ,'SANTO TOMAS LA UNION'
           ,'SANTOTOMASLAUNION'
           ,'10'
           ,'ebee1e02-ea28-4afa-b2c0-04e2eb552d30'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1018
           ,199
           ,'ZUNILITO'
           ,'ZUNILITO'
           ,'10'
           ,'c41421a7-33b9-4af8-8843-cacccbf2222a'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1019
           ,200
           ,'PUEBLO NUEVO'
           ,'PUEBLONUEVO'
           ,'10'
           ,'924f84a6-2264-4a40-87fe-3a3df378ad9f'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1020
           ,201
           ,'RIO BRAVO'
           ,'RIOBRAVO'
           ,'10'
           ,'cf775fc4-d1e7-43fb-ae5d-c7017eeec48e'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1101
           ,202
           ,'RETALHULEU'
           ,'RETALHULEU'
           ,'11'
           ,'a0c9be84-0448-4123-82b1-83d5481b151f'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1102
           ,203
           ,'SAN SEBASTIAN'
           ,'SANSEBASTIAN'
           ,'11'
           ,'45fb5775-4741-47be-875c-981ada6198a3'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1103
           ,204
           ,'SANTA CRUZ MULUA'
           ,'SANTACRUZMULUA'
           ,'11'
           ,'896d7e85-cbda-4285-a143-4fe3d5d0e0d4'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1104
           ,205
           ,'SAN MARTIN ZAPOTITLAN'
           ,'SANMARTINZAPOTITLAN'
           ,'11'
           ,'6cf238bc-89d3-40d3-9223-597d24f8cf0c'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1105
           ,206
           ,'SAN FELIPE'
           ,'SANFELIPE'
           ,'11'
           ,'a5ff722a-1c5d-4657-b62f-4cf9fdfc2500'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1106
           ,207
           ,'SAN ANDRES VILLA  SECA'
           ,'SANANDRESVILLASECA'
           ,'11'
           ,'61b09b3d-13c0-4b13-9172-cc112fbf4046'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1107
           ,208
           ,'CHAPERICO'
           ,'CHAPERICO'
           ,'11'
           ,'f707f524-5227-4470-804e-134d4c98b07c'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1108
           ,209
           ,'NUEVO SAN CARLOS'
           ,'NUEVOSANCARLOS'
           ,'11'
           ,'ea0a3a43-da51-4919-b847-e175d6e940fd'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1109
           ,210
           ,'EL ASINTAL'
           ,'ELASINTAL'
           ,'11'
           ,'8097a60f-11c3-4c40-a873-d21e17f87665'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1201
           ,211
           ,'SAN MARCOS'
           ,'SANMARCOS'
           ,'12'
           ,'b1324d94-9044-4108-9e46-0b531d582b75'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1202
           ,212
           ,'SAN PEDRO SACATEPEQUEZ'
           ,'SANPEDROSACATEPEQUEZ'
           ,'12'
           ,'0c62c34e-7794-4e3a-8aa4-f76d7251bde6'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1203
           ,213
           ,'SAN ANTONIO SACATEPEQUEZ'
           ,'SANANTONIOSACATEPEQUEZ'
           ,'12'
           ,'6598e4c2-9756-4dc0-a706-1bc3db46c007'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1204
           ,214
           ,'COMITANCILLO'
           ,'COMITANCILLO'
           ,'12'
           ,'3fdfe0cf-fb15-499f-884c-85674fb7c205'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1205
           ,215
           ,'SAN MIGUEL IXTAHUACAN'
           ,'SANMIGUELIXTAHUACAN'
           ,'12'
           ,'46786360-bcb4-4e14-b412-bd118f7b138c'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1206
           ,216
           ,'CONCEPCION TUTUAPA'
           ,'CONCEPCIONTUTUAPA'
           ,'12'
           ,'68407cfe-d056-4ec8-8e03-a21194a03750'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1207
           ,217
           ,'TACANA'
           ,'TACANA'
           ,'12'
           ,'148ff4c6-3d9b-43c0-8b9d-7e68517865c6'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1208
           ,218
           ,'SIBINAL'
           ,'SIBINAL'
           ,'12'
           ,'6ef8f58a-7ddf-4ed1-bde3-16c44e5a4a3e'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1209
           ,219
           ,'TAJUMULCO'
           ,'TAJUMULCO'
           ,'12'
           ,'7d08fd04-cdad-43dd-b5d5-b3d4eeff27ba'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1210
           ,220
           ,'TEJUTLA'
           ,'TEJUTLA'
           ,'12'
           ,'ccabb92b-b051-48fe-888d-7122ec28845c'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1211
           ,221
           ,'SAN RAFAEL PIE DE LA CUESTA'
           ,'SANRAFAELPIEDELACUESTA'
           ,'12'
           ,'59e666ca-62c9-4643-ae7b-a8495131e400'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1212
           ,222
           ,'NUEVO PROGRESO'
           ,'NUEVOPROGRESO'
           ,'12'
           ,'ae5cded9-58c8-43a6-b845-44bcc344c8d8'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1213
           ,223
           ,'EL TUMBADOR'
           ,'ELTUMBADOR'
           ,'12'
           ,'7d4e015d-eeb6-4e99-92cd-370c3259a6b5'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1214
           ,224
           ,'EL RODEO'
           ,'ELRODEO'
           ,'12'
           ,'3dbc1bfc-f8ea-4576-bdf9-59198217b6c6'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1215
           ,225
           ,'MALACATAN'
           ,'MALACATAN'
           ,'12'
           ,'fda7a0a1-81e5-4b2a-83ad-d11825071792'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1216
           ,226
           ,'CATARINA'
           ,'CATARINA'
           ,'12'
           ,'0e2121b7-d9fd-492f-be5c-23bf77a9f6dc'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1217
           ,227
           ,'AYUTLA'
           ,'AYUTLA'
           ,'12'
           ,'2cbdd16f-5121-4eac-8fbb-c0af84119aa1'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1218
           ,228
           ,'OCOS'
           ,'OCOS'
           ,'12'
           ,'b62a6cf1-656e-4b4f-9b51-c733097726bb'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1219
           ,229
           ,'SAN PABLO'
           ,'SANPABLO'
           ,'12'
           ,'0283532b-6eae-4cd1-8019-441d8845b726'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1220
           ,230
           ,'EL QUETZAL'
           ,'ELQUETZAL'
           ,'12'
           ,'9c3f8d2c-cb8a-431f-9b48-7e489e182f53'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1221
           ,231
           ,'LA REFORMA'
           ,'LAREFORMA'
           ,'12'
           ,'957fa3ae-fa57-42c8-8235-e709e043f972'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1222
           ,232
           ,'PAJAPITA'
           ,'PAJAPITA'
           ,'12'
           ,'09b488ea-bfc4-4cc1-832b-020755e88efe'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1223
           ,233
           ,'IXCHIGUAN'
           ,'IXCHIGUAN'
           ,'12'
           ,'73b5794c-2dc3-4cd2-9635-d65ee0ab47c3'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1224
           ,234
           ,'SAN JOSE OJETENAM'
           ,'SANJOSEOJETENAM'
           ,'12'
           ,'046bbf24-adac-4f22-8107-d6effcfd8a89'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1225
           ,235
           ,'SAN CRISTOBAL CUCHO'
           ,'SANCRISTOBALCUCHO'
           ,'12'
           ,'6d5c9192-c7a9-457e-bd09-9538946a3650'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1226
           ,236
           ,'SIPACAPA'
           ,'SIPACAPA'
           ,'12'
           ,'3d7efe50-e890-46ba-965f-b69a5e86c51a'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1227
           ,237
           ,'ESQUIPULAS PALO GORDO'
           ,'ESQUIPULASPALOGORDO'
           ,'12'
           ,'895d99be-378f-4f5f-bf65-337788b39ca3'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1228
           ,238
           ,'RIO BLANCO'
           ,'RIOBLANCO'
           ,'12'
           ,'fb20c3e7-5a7e-4177-b69e-4d5a559e9cd9'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1229
           ,239
           ,'SAN LORENZO'
           ,'SANLORENZO'
           ,'12'
           ,'775d8588-8fdf-474f-97f6-7308033ee0e5'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1301
           ,240
           ,'HUEHUETENANGO'
           ,'HUEHUETENANGO'
           ,'13'
           ,'345c6074-add1-4797-a408-d7ab532dda64'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1302
           ,241
           ,'CHIANTLA'
           ,'CHIANTLA'
           ,'13'
           ,'37fc9ebc-b736-41e3-8d4b-c9fb6be20cb9'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1303
           ,242
           ,'MALACATANCITO'
           ,'MALACATANCITO'
           ,'13'
           ,'bdc4e35a-2345-4ba9-aa0a-80b6501a0495'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1304
           ,243
           ,'CUILCO'
           ,'CUILCO'
           ,'13'
           ,'a71ce2bf-3c4b-43ff-a199-de334a99f9fe'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1305
           ,244
           ,'NENTON'
           ,'NENTON'
           ,'13'
           ,'049a515b-0aec-42e6-bd36-36ab19bf85c1'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1306
           ,245
           ,'SAN PEDRO NECTA'
           ,'SANPEDRONECTA'
           ,'13'
           ,'8ebb9a59-02ac-4c06-8522-eb2904d5de7f'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1307
           ,246
           ,'JACALTENANGO'
           ,'JACALTENANGO'
           ,'13'
           ,'7416cca3-b089-43d3-b7e8-ab5a65eac46f'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1308
           ,247
           ,'SOLOMA'
           ,'SOLOMA'
           ,'13'
           ,'9d744a9a-0d5e-44b3-92ff-927aab36884e'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1309
           ,248
           ,'IXTAHUACAN'
           ,'IXTAHUACAN'
           ,'13'
           ,'e15305ec-8997-41eb-8e68-8ec24f8af41c'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1310
           ,249
           ,'STA. BARBARA'
           ,'STABARBARA'
           ,'13'
           ,'3cbffe3a-e230-4770-a217-192ee0ab4963'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1311
           ,250
           ,'LA LIBERTAD'
           ,'LALIBERTAD'
           ,'13'
           ,'901b405d-d663-4832-ad6b-95d08ea47b27'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1312
           ,251
           ,'LA DEMOCRACIA'
           ,'LADEMOCRACIA'
           ,'13'
           ,'6401f6f5-3c3f-4ce6-98a2-7075bc24e51b'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1313
           ,252
           ,'SAN MIGUEL ACATAN'
           ,'SANMIGUELACATAN'
           ,'13'
           ,'a9c3d457-3630-4a7b-a55d-7224ecdcf6cf'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1314
           ,253
           ,'SAN RAFAEL LA INDEPENDENCIA'
           ,'SANRAFAELLAINDEPENDENCIA'
           ,'13'
           ,'34e7eb4d-9396-4bcf-8f11-b3ba0623bad3'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1315
           ,254
           ,'TODOS SANTOS CUCHUMATAN'
           ,'TODOSSANTOSCUCHUMATAN'
           ,'13'
           ,'b574c46b-22f3-4f5e-8435-a14089bddca5'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1316
           ,255
           ,'SAN JUAN ATITAN'
           ,'SANJUANATITAN'
           ,'13'
           ,'ca08f328-e2e6-41d7-a10d-4c765e28b6cc'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1317
           ,256
           ,'SANTA EULALIA'
           ,'SANTAEULALIA'
           ,'13'
           ,'1bd58a42-9d68-4752-89b0-c84c2c79498b'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1318
           ,257
           ,'SAN MATEO IXTATAN'
           ,'SANMATEOIXTATAN'
           ,'13'
           ,'26b49d70-53b1-436a-95e1-740226ff5869'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1319
           ,258
           ,'COLOTENANGO'
           ,'COLOTENANGO'
           ,'13'
           ,'44d81c0b-9a3d-44e9-80dc-9be07bdd7551'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1320
           ,259
           ,'SAN SEBASTIAN HUEHUETENANGO'
           ,'SANSEBASTIANHUEHUETENANGO'
           ,'13'
           ,'1ea61f5a-6f60-4cd6-8dfc-860858be27c9'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1321
           ,260
           ,'TECTITAN'
           ,'TECTITAN'
           ,'13'
           ,'b7367493-7452-43b1-bc91-9d006e682f4a'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1322
           ,261
           ,'CONCEPCION HUISTA'
           ,'CONCEPCIONHUISTA'
           ,'13'
           ,'236bcd6a-42bd-4231-a6bf-c8d414d1ef41'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1323
           ,262
           ,'SAN JUAN IXCOY'
           ,'SANJUANIXCOY'
           ,'13'
           ,'826f846a-f42b-43d6-97ca-3b3af52f5c41'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1324
           ,263
           ,'SAN ANTONIO HUISTA'
           ,'SANANTONIOHUISTA'
           ,'13'
           ,'2a6088e1-38c8-45d7-b68b-ab5526cd25a8'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1325
           ,264
           ,'SAN SEBASTIAN COATAN'
           ,'SANSEBASTIANCOATAN'
           ,'13'
           ,'343025a3-8fb8-4dd2-be3c-1c7e6cf77444'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1326
           ,265
           ,'BARILLAS'
           ,'BARILLAS'
           ,'13'
           ,'1bcc4c5e-2f1c-4ca1-8cfe-59180cc00b90'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1327
           ,266
           ,'AGUACATAN'
           ,'AGUACATAN'
           ,'13'
           ,'93e63574-22bd-471e-85c8-9518bd66555c'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1328
           ,267
           ,'SAN RAFAEL PETZAL'
           ,'SANRAFAELPETZAL'
           ,'13'
           ,'da49e81f-90e6-444b-b47c-9df522792b62'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1329
           ,268
           ,'SAN GASPAR IXCHIL'
           ,'SANGASPARIXCHIL'
           ,'13'
           ,'9af0db51-772d-4a81-97a2-120b9d35f65f'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1330
           ,269
           ,'SANTIAGO CHIMALTENANGO'
           ,'SANTIAGOCHIMALTENANGO'
           ,'13'
           ,'a8a6d096-394b-4ee7-b724-dd9a0afca0f6'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1331
           ,270
           ,'SAN ANA HUISTA'
           ,'SANANAHUISTA'
           ,'13'
           ,'bf1a3332-2ed7-4a3b-8074-aa09bc5be7ba'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1401
           ,271
           ,'SANTA CRUZ DEL QUICHE'
           ,'SANTACRUZDELQUICHE'
           ,'14'
           ,'66b8555f-5183-4a4a-a5b8-be844e92ce9a'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1402
           ,272
           ,'CHICHE'
           ,'CHICHE'
           ,'14'
           ,'a78c1779-a8c1-49e4-9cbd-0e78fdc4d78e'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1403
           ,273
           ,'CHINIQUE'
           ,'CHINIQUE'
           ,'14'
           ,'d0f1aace-6f80-4bea-a863-689d3e96fe01'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1404
           ,274
           ,'ZACUALPA'
           ,'ZACUALPA'
           ,'14'
           ,'e9aec69e-550a-40d7-8cde-7cc6204db7b9'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1405
           ,275
           ,'CHAJUL'
           ,'CHAJUL'
           ,'14'
           ,'05a71f4d-fd29-4668-a376-29ce80d0bbd8'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1406
           ,276
           ,'CHICHICASTENANGO'
           ,'CHICHICASTENANGO'
           ,'14'
           ,'ae142144-1c25-4528-8a4b-41d78b91837d'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1407
           ,277
           ,'PATZITE'
           ,'PATZITE'
           ,'14'
           ,'f80a5290-28f6-4f31-8315-bfc44d003eac'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1408
           ,278
           ,'SAN ANTONIO ILOTENANGO'
           ,'SANANTONIOILOTENANGO'
           ,'14'
           ,'e3261962-11ed-4a39-b668-67ae74ec10c8'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1409
           ,279
           ,'SAN PEDRO JOCOPILAS'
           ,'SANPEDROJOCOPILAS'
           ,'14'
           ,'736cef20-b4e8-4ea4-932b-e4db8f30bbdb'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1410
           ,280
           ,'CUNEN'
           ,'CUNEN'
           ,'14'
           ,'bb252230-7759-46f4-9652-e1d9a6b213df'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1411
           ,281
           ,'SAN JUAN COTZAL'
           ,'SANJUANCOTZAL'
           ,'14'
           ,'4a227d5c-4ea7-4fc8-8a30-339ebba3dbfb'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1412
           ,282
           ,'JOYABAJ'
           ,'JOYABAJ'
           ,'14'
           ,'09ff28f7-b8ba-4173-81a6-e70f38bc437e'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1413
           ,283
           ,'NEBAJ'
           ,'NEBAJ'
           ,'14'
           ,'6cf517b4-426c-483d-a2a0-80f2e926daab'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1414
           ,284
           ,'SAN ANDRES SAJCABAJA'
           ,'SANANDRESSAJCABAJA'
           ,'14'
           ,'14c010dc-ec7d-4f48-b462-e1c9258e9891'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1415
           ,285
           ,'USPANTAN'
           ,'USPANTAN'
           ,'14'
           ,'6243c106-98f4-45e8-ace5-5756e764200e'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1416
           ,286
           ,'SACAPULAS'
           ,'SACAPULAS'
           ,'14'
           ,'e90f3e5d-a063-4e5c-bb8c-e6f1b4b200fc'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1417
           ,287
           ,'SAN BARTOLOME JOCOTENANGO'
           ,'SANBARTOLOMEJOCOTENANGO'
           ,'14'
           ,'1b3aefdd-ef3a-41a6-916e-8fdea757d5b8'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1418
           ,288
           ,'CANILLA'
           ,'CANILLA'
           ,'14'
           ,'8ba656b7-9610-4b4b-acdb-e26b35eb1448'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1419
           ,289
           ,'CHICAMAN'
           ,'CHICAMAN'
           ,'14'
           ,'9587ff99-cd0d-4aab-a3c4-96c88a31ad00'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1420
           ,290
           ,'IXCAN'
           ,'IXCAN'
           ,'14'
           ,'72e5f283-0331-4f1c-8493-922cf536e30d'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1421
           ,291
           ,'PACHALUM'
           ,'PACHALUM'
           ,'14'
           ,'236aad72-6cdf-4b5f-aabf-1478396b1e88'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1501
           ,292
           ,'SALAMA'
           ,'SALAMA'
           ,'15'
           ,'c57f2e97-3018-4c36-ac7a-d1d0a4643372'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1502
           ,293
           ,'SAN MIGUEL CHICAJ'
           ,'SANMIGUELCHICAJ'
           ,'15'
           ,'95fd2cde-da05-44a4-afc9-5074f5f3730f'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1503
           ,294
           ,'RABINAL'
           ,'RABINAL'
           ,'15'
           ,'08b6b663-f740-45c4-9287-aeddb05f7b9b'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1504
           ,295
           ,'CUBULCO'
           ,'CUBULCO'
           ,'15'
           ,'13d41017-5788-4b7e-b1c0-4bee2dd5d5fa'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1505
           ,296
           ,'GRANADOS'
           ,'GRANADOS'
           ,'15'
           ,'32a1607b-78be-4622-b6ae-7338fae46823'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1506
           ,297
           ,'EL CHOL'
           ,'ELCHOL'
           ,'15'
           ,'c0ecaa32-a42f-4ebe-bed8-505197bcaef7'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1507
           ,298
           ,'SAN JERONIMO'
           ,'SANJERONIMO'
           ,'15'
           ,'dbabc9f3-8a66-47e5-9f92-8ab475064ca1'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1508
           ,299
           ,'PURULHA'
           ,'PURULHA'
           ,'15'
           ,'dd07b01f-e533-413b-beb6-59919bd3c969'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1601
           ,300
           ,'COBAN'
           ,'COBAN'
           ,'16'
           ,'1af977f8-ccdc-4ed0-90e0-08984edd4a2e'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1602
           ,301
           ,'SANTA CRUZ VERAPAZ'
           ,'SANTACRUZVERAPAZ'
           ,'16'
           ,'15df302b-b5d3-4f3a-9b1a-1cc3b9f333b4'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1603
           ,302
           ,'SAN CRISTOBAL VERAPAZ'
           ,'SANCRISTOBALVERAPAZ'
           ,'16'
           ,'71791aeb-94a9-4512-ad23-361c11f5be3d'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1604
           ,303
           ,'TACTIC'
           ,'TACTIC'
           ,'16'
           ,'e575b9b9-3a9f-48ba-bb70-2456d4c796fb'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1605
           ,304
           ,'TAMAHU'
           ,'TAMAHU'
           ,'16'
           ,'7c321d15-3a96-4fcd-8ef9-3215c78c83c5'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1606
           ,305
           ,'TUCURU'
           ,'TUCURU'
           ,'16'
           ,'48c97f53-8bab-4cc9-b300-6b30b97c0037'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1607
           ,306
           ,'PANZOS'
           ,'PANZOS'
           ,'16'
           ,'6905e3d8-c684-435f-9d7e-2b3308cbe5af'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1608
           ,307
           ,'SENAHU'
           ,'SENAHU'
           ,'16'
           ,'9d3baea1-d690-4347-849a-3d0c098e4432'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1609
           ,308
           ,'SAN PEDRO CARCHA'
           ,'SANPEDROCARCHA'
           ,'16'
           ,'d0ce2e84-b560-4a21-8186-82298ae1bf12'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1610
           ,309
           ,'SAN JUAN CHAMELCO'
           ,'SANJUANCHAMELCO'
           ,'16'
           ,'5c23ad4d-557d-4ecf-8184-a7a15cc5cf47'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1611
           ,310
           ,'LANQUIN'
           ,'LANQUIN'
           ,'16'
           ,'00904a35-623d-4d6b-8b0e-e2eefc8cb872'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1612
           ,311
           ,'CAHABON'
           ,'CAHABON'
           ,'16'
           ,'cf1b1481-4010-4d5d-9793-f99d86b6623c'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1613
           ,312
           ,'CHISEC'
           ,'CHISEC'
           ,'16'
           ,'c8ed7632-7911-42dc-a0d8-9617ae4f6fed'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1614
           ,313
           ,'CHAHAL'
           ,'CHAHAL'
           ,'16'
           ,'4429cc4b-66f8-429c-90d6-3968d2e7dac3'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1615
           ,314
           ,'FRAY BARTOLOME DE LAS CASAS'
           ,'FRAYBARTOLOMEDELASCASAS'
           ,'16'
           ,'709db94e-4f44-46c9-8486-bec1c4b648ca'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1616
           ,315
           ,'LA TINTA'
           ,'LATINTA'
           ,'16'
           ,'8d5edbd3-91cf-49a4-a778-db0535a79515'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1701
           ,316
           ,'FLORES'
           ,'FLORES'
           ,'17'
           ,'2c8a228b-ef7a-4bc8-88c2-1d8ec5cafd9c'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1702
           ,317
           ,'SAN JOSE'
           ,'SANJOSE'
           ,'17'
           ,'f1a695e5-1d3d-4c27-be2d-3f8e758981b8'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1703
           ,318
           ,'SAN BENITO'
           ,'SANBENITO'
           ,'17'
           ,'6f042f77-b996-4541-8ebd-2eddc6caa0f8'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1704
           ,319
           ,'SAN ANDRES'
           ,'SANANDRES'
           ,'17'
           ,'498d6b2d-5778-4048-8510-300428a0185c'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1705
           ,320
           ,'LA LIBERTAD'
           ,'LALIBERTAD'
           ,'17'
           ,'40299335-9c71-4c39-89cd-644b6981a6c4'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1706
           ,321
           ,'SAN FRANCISCO'
           ,'SANFRANCISCO'
           ,'17'
           ,'c6d0b6fb-f2cb-46df-88b9-9db20898cdfa'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1707
           ,322
           ,'SANTA ANA'
           ,'SANTAANA'
           ,'17'
           ,'c1a8881d-abe4-41e9-a5c3-febe6f8af0d5'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1708
           ,323
           ,'DOLORES'
           ,'DOLORES'
           ,'17'
           ,'f91a3043-7dde-496e-ab2a-d082c9c6553a'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1709
           ,324
           ,'SAN LUIS'
           ,'SANLUIS'
           ,'17'
           ,'cc287a73-d6b5-4033-b8a2-4e74a4525138'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1710
           ,325
           ,'SAYAXCHE'
           ,'SAYAXCHE'
           ,'17'
           ,'e30e7a87-5756-4454-ba33-8616cb1d7471'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1711
           ,326
           ,'MELCHOR DE MENCOS'
           ,'MELCHORDEMENCOS'
           ,'17'
           ,'6a9a3ee2-0ad7-443e-b84f-b3e0bec25ecf'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1712
           ,327
           ,'POPTUN'
           ,'POPTUN'
           ,'17'
           ,'4428a443-4324-4cf0-9fc8-6ed294671479'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1713
           ,328
           ,'LAGO PETEN ITZA'
           ,'LAGOPETENITZA'
           ,'17'
           ,'4abbca87-7776-43dd-bfe7-d382100e539c'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1801
           ,329
           ,'PUERTO BARRIOS'
           ,'PUERTOBARRIOS'
           ,'18'
           ,'1b761383-f9d5-41da-a198-23eba4d16a9d'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1802
           ,330
           ,'LIVINGSTON'
           ,'LIVINGSTON'
           ,'18'
           ,'90fcf2f7-b75d-4d8f-876c-fd9bdd6fb15e'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1803
           ,331
           ,'EL ESTOR'
           ,'ELESTOR'
           ,'18'
           ,'a3167c3f-0789-4db0-bd84-b0f049790a1d'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1804
           ,332
           ,'MORALES'
           ,'MORALES'
           ,'18'
           ,'93a372e6-ee5f-4a67-92a3-0e0d80e29eaa'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1805
           ,333
           ,'LOS AMATES'
           ,'LOSAMATES'
           ,'18'
           ,'ce359a59-ea24-4171-a4cd-27313a22dcb5'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1901
           ,334
           ,'ZACAPA'
           ,'ZACAPA'
           ,'18'
           ,'418b6b92-d10f-4046-a37d-9a7edb890ec5'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1902
           ,335
           ,'ESTANZUELA'
           ,'ESTANZUELA'
           ,'18'
           ,'3faf47f2-0ec0-4700-8452-47a602a1dbf0'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1903
           ,336
           ,'RIO HONDO'
           ,'RIOHONDO'
           ,'18'
           ,'99001d3b-0a70-4fa4-b68b-4acb979c07e0'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1904
           ,337
           ,'GUALAN'
           ,'GUALAN'
           ,'18'
           ,'638e738b-e8b4-47b3-af30-f9c9c1afa6f0'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1905
           ,338
           ,'TECULUTAN'
           ,'TECULUTAN'
           ,'18'
           ,'5cc688a2-b0ab-409d-8469-abc258be4026'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1906
           ,339
           ,'USUMATLAN'
           ,'USUMATLAN'
           ,'18'
           ,'c6303ff0-c295-4400-bc2a-f70280becd3d'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1907
           ,340
           ,'CABAÑAS'
           ,'CABANAS'
           ,'18'
           ,'869e587b-8af7-40c2-90d5-1ed61787cffc'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1908
           ,341
           ,'SAN DIEGO'
           ,'SANDIEGO'
           ,'18'
           ,'0f85df5b-cb1c-4264-bf11-059d7c91b6a7'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1909
           ,342
           ,'LA UNION'
           ,'LAUNION'
           ,'18'
           ,'2ab959f2-45d5-4a76-b314-3cc736810a32'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1910
           ,343
           ,'HUITE'
           ,'HUITE'
           ,'18'
           ,'35387878-5f54-4306-b28a-b40b3da755e8'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (2001
           ,344
           ,'CHIQUIMULA'
           ,'CHIQUIMULA'
           ,'20'
           ,'6a4ceea4-d3d0-4102-ba98-dc5ef62dabd4'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (2002
           ,345
           ,'SAN JOSE LA ARADA'
           ,'SANJOSELAARADA'
           ,'20'
           ,'c9a3d737-ca4d-4d9f-895d-fd11a150af94'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (2003
           ,346
           ,'SAN JUAN ERMITA'
           ,'SANJUANERMITA'
           ,'20'
           ,'a3e4a461-2697-45be-b723-8e17825698a3'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (2004
           ,347
           ,'JOCOTAN'
           ,'JOCOTAN'
           ,'20'
           ,'98734246-bf8c-414b-ab82-4b220d8212ca'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (2005
           ,348
           ,'CAMOTAN'
           ,'CAMOTAN'
           ,'20'
           ,'705ab76a-9944-4576-a114-7f0d3df60e40'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (2006
           ,349
           ,'OLOPA'
           ,'OLOPA'
           ,'20'
           ,'0c7bc66d-46f8-448b-8ae1-9abe0cea907a'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (2007
           ,350
           ,'ESQUIPULAS'
           ,'ESQUIPULAS'
           ,'20'
           ,'ecd979ff-a16b-47ff-a872-10f1488714ba'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (2008
           ,351
           ,'CONCEPCION LAS MINAS'
           ,'CONCEPCIONLASMINAS'
           ,'20'
           ,'7e67b979-fd31-4f92-ae4b-620f5d82c469'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (2009
           ,352
           ,'QUETZALTEPEQUE'
           ,'QUETZALTEPEQUE'
           ,'20'
           ,'ac3225d7-74ce-4201-a72c-2b4409e7eaf3'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (2010
           ,353
           ,'SAN JACINTO'
           ,'SANJACINTO'
           ,'20'
           ,'cf3b9848-bc83-478e-88a5-b70739e586e6'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Municipio]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (2011
           ,354
           ,'IPALA'
           ,'IPALA'
           ,'20'
           ,'14e6ac13-7660-4f60-a7b3-046d8c7a82e4'
           ,'0'
		   );
CREATE TABLE [LegalValue].[LV_Nombre]
(
	[Value] [int] NULL
	,[Order] [int] NULL
	,[Text] [nvarchar](200) NULL
	,[ShortName] [nvarchar](50) NULL
	,[Group] [nvarchar](50) NULL
	,[Hidden] [bit] NULL
    ,[LegalValueItemGUID] UNIQUEIDENTIFIER NULL
);
INSERT INTO [LegalValue].[LV_Nombre]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1
           ,1
           ,'JOSÉ'
           ,NULL
           ,NULL
           ,'870b0f9a-a970-4b48-857c-2c61d7cc46e8'
           ,'0'
		   );
CREATE TABLE [LegalValue].[LV_PosNeg]
(
	[Value] [int] NULL
	,[Order] [int] NULL
	,[Text] [nvarchar](200) NULL
	,[ShortName] [nvarchar](50) NULL
	,[Group] [nvarchar](50) NULL
	,[Hidden] [bit] NULL
    ,[LegalValueItemGUID] UNIQUEIDENTIFIER NULL
);
INSERT INTO [LegalValue].[LV_PosNeg]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1
           ,1
           ,'Positivo'
           ,'Positivo'
           ,NULL
           ,'60dd891a-1b3b-477f-ae87-0c6986a3c819'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_PosNeg]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (2
           ,2
           ,'Negativo'
           ,'Negativo'
           ,NULL
           ,'3243d97b-f3a3-4204-9319-41dc874d6e80'
           ,'0'
		   );
CREATE TABLE [LegalValue].[LV_Sexo]
(
	[Value] [int] NULL
	,[Order] [int] NULL
	,[Text] [nvarchar](200) NULL
	,[ShortName] [nvarchar](50) NULL
	,[Group] [nvarchar](50) NULL
	,[Hidden] [bit] NULL
    ,[LegalValueItemGUID] UNIQUEIDENTIFIER NULL
);
INSERT INTO [LegalValue].[LV_Sexo]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1
           ,1
           ,'Masculino'
           ,'Masculino'
           ,NULL
           ,'4794df43-cfd8-467b-83dd-36785c2daa91'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_Sexo]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (2
           ,2
           ,'Femenino'
           ,'Femenino'
           ,NULL
           ,'90cf0192-0d15-4c9a-a07c-4a8e56328d08'
           ,'0'
		   );
CREATE TABLE [LegalValue].[LV_SiNo]
(
	[Value] [int] NULL
	,[Order] [int] NULL
	,[Text] [nvarchar](200) NULL
	,[ShortName] [nvarchar](50) NULL
	,[Group] [nvarchar](50) NULL
	,[Hidden] [bit] NULL
    ,[LegalValueItemGUID] UNIQUEIDENTIFIER NULL
);
INSERT INTO [LegalValue].[LV_SiNo]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1
           ,1
           ,'Sí'
           ,'Si'
           ,NULL
           ,'07793f4d-ea48-4428-b004-ca42a21fb73c'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_SiNo]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (2
           ,2
           ,'No'
           ,'No'
           ,NULL
           ,'595482e6-80c4-4561-82f6-8e058a493c62'
           ,'0'
		   );
CREATE TABLE [LegalValue].[LV_SiNoNA]
(
	[Value] [int] NULL
	,[Order] [int] NULL
	,[Text] [nvarchar](200) NULL
	,[ShortName] [nvarchar](50) NULL
	,[Group] [nvarchar](50) NULL
	,[Hidden] [bit] NULL
    ,[LegalValueItemGUID] UNIQUEIDENTIFIER NULL
);
INSERT INTO [LegalValue].[LV_SiNoNA]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1
           ,1
           ,'Sí'
           ,'Si'
           ,NULL
           ,'3d7b6709-7b38-45c0-a60a-bfa205e5c466'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_SiNoNA]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (2
           ,2
           ,'No'
           ,'No'
           ,NULL
           ,'eab74a94-66db-42cc-84fb-68318b4e6170'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_SiNoNA]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (98
           ,3
           ,'No Aplica'
           ,'NA'
           ,NULL
           ,'c7f70e01-b959-4c0d-8a7f-f977180255fd'
           ,'0'
		   );
CREATE TABLE [LegalValue].[LV_SiNoNS]
(
	[Value] [int] NULL
	,[Order] [int] NULL
	,[Text] [nvarchar](200) NULL
	,[ShortName] [nvarchar](50) NULL
	,[Group] [nvarchar](50) NULL
	,[Hidden] [bit] NULL
    ,[LegalValueItemGUID] UNIQUEIDENTIFIER NULL
);
INSERT INTO [LegalValue].[LV_SiNoNS]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (1
           ,1
           ,'Sí'
           ,'Si'
           ,NULL
           ,'7e30c992-6082-4dcc-bb53-a0ab47af7866'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_SiNoNS]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (2
           ,2
           ,'No'
           ,'No'
           ,NULL
           ,'f1f0b50a-6ac2-40d1-acfa-9077a13e9290'
           ,'0'
		   );
INSERT INTO [LegalValue].[LV_SiNoNS]
           ([Value]
           ,[Order]
           ,[Text]
           ,[ShortName]
           ,[Group]
           ,[LegalValueItemGUID]
           ,[Hidden])
     VALUES
           (99
           ,3
           ,'No Sabe'
           ,'NS'
           ,NULL
           ,'5974dc65-ff0b-4368-be48-ca78d3db3c47'
           ,'0'
		   );
